import React, { useState } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { EmployeeWithManager } from "@shared/schema";
import { formatToInputDate } from "@/lib/date-utils";

// Create a schema for employee validation
const employeeSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters" }),
  email: z.string().email({ message: "Please enter a valid email address" }),
  employeeId: z.string().min(1, { message: "Employee ID is required" }),
  position: z.string().min(1, { message: "Position is required" }),
  department: z.string().min(1, { message: "Department is required" }),
  managerId: z.number().nullable(),
  joinDate: z.string().min(1, { message: "Join date is required" }),
  isActive: z.boolean().default(true),
});

type EmployeeFormValues = z.infer<typeof employeeSchema>;

interface EmployeeFormProps {
  initialData?: Partial<EmployeeWithManager>;
  onSubmit: (data: Partial<EmployeeWithManager>) => Promise<void>;
  submitLabel: string;
  allEmployees?: EmployeeWithManager[];
}

export default function EmployeeForm({
  initialData,
  onSubmit,
  submitLabel,
  allEmployees = [],
}: EmployeeFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Exclude current employee from potential managers list
  const potentialManagers = allEmployees.filter(
    (emp) => !initialData || emp.id !== initialData.id
  );

  // Initialize the form with default values
  const form = useForm<EmployeeFormValues>({
    resolver: zodResolver(employeeSchema),
    defaultValues: {
      name: initialData?.name || "",
      email: initialData?.email || "",
      employeeId: initialData?.employeeId || "",
      position: initialData?.position || "",
      department: initialData?.department || "",
      managerId: initialData?.managerId || null,
      joinDate: initialData?.joinDate 
        ? formatToInputDate(initialData.joinDate) 
        : formatToInputDate(new Date()),
      isActive: initialData?.isActive ?? true,
    },
  });

  const handleSubmit = async (values: EmployeeFormValues) => {
    setIsSubmitting(true);
    try {
      // Convert managerId to number if it's a string (from select)
      const formattedValues = {
        ...values,
        managerId: values.managerId === null 
          ? null 
          : typeof values.managerId === 'string' 
            ? parseInt(values.managerId) 
            : values.managerId,
        joinDate: new Date(values.joinDate),
      };
      
      await onSubmit(formattedValues);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Name</FormLabel>
                <FormControl>
                  <Input placeholder="John Doe" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="email"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Email</FormLabel>
                <FormControl>
                  <Input placeholder="john.doe@example.com" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="employeeId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Employee ID</FormLabel>
                <FormControl>
                  <Input placeholder="EMP001" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="position"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Position</FormLabel>
                <FormControl>
                  <Input placeholder="Software Engineer" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="department"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Department</FormLabel>
                <FormControl>
                  <Input placeholder="Engineering" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="managerId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Line Manager</FormLabel>
                <Select
                  onValueChange={(value) => 
                    field.onChange(value === "" ? null : parseInt(value))
                  }
                  value={field.value?.toString() || ""}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a manager" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="">None</SelectItem>
                    {potentialManagers.map((manager) => (
                      <SelectItem 
                        key={manager.id} 
                        value={manager.id.toString()}
                      >
                        {manager.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="joinDate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Join Date</FormLabel>
                <FormControl>
                  <Input type="date" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="flex justify-end space-x-2 pt-4">
          <Button
            type="submit"
            disabled={isSubmitting}
          >
            {isSubmitting ? (
              <span className="flex items-center gap-1">
                <span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent"></span>
                Submitting...
              </span>
            ) : (
              submitLabel
            )}
          </Button>
        </div>
      </form>
    </Form>
  );
}
