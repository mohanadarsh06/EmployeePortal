import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface StatCardProps {
  title: string;
  value: string | number;
  icon: string;
  colorClass: string;
  iconBgClass: string;
}

export function StatCard({
  title,
  value,
  icon,
  colorClass,
  iconBgClass
}: StatCardProps) {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-neutral-gray text-sm">{title}</p>
            <p className="text-2xl font-medium mt-1">{value}</p>
          </div>
          <div className={cn("p-2 rounded-full", iconBgClass)}>
            <span className={cn("material-icons", colorClass)}>{icon}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export function TeamMembersCard({ value }: { value: number }) {
  return (
    <StatCard
      title="Total Team Members"
      value={value}
      icon="groups"
      colorClass="text-primary-main"
      iconBgClass="bg-primary-light bg-opacity-10"
    />
  );
}

export function FeedbackGivenCard({ value }: { value: number }) {
  return (
    <StatCard
      title="Feedback Given (Month)"
      value={value}
      icon="comment"
      colorClass="text-secondary-main"
      iconBgClass="bg-secondary-light bg-opacity-10"
    />
  );
}

export function PendingFeedbackCard({ value }: { value: number }) {
  return (
    <StatCard
      title="Pending Feedback"
      value={value}
      icon="pending_actions"
      colorClass="text-status-warning"
      iconBgClass="bg-status-warning-light"
    />
  );
}

export function AvgScoreCard({ value }: { value: string }) {
  return (
    <StatCard
      title="Avg. Feedback Score"
      value={value}
      icon="star"
      colorClass="text-status-success"
      iconBgClass="bg-status-success-light"
    />
  );
}
