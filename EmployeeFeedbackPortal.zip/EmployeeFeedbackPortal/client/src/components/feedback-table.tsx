import { useState } from "react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import UserAvatar from "./UserAvatar";
import StarRating from "./star-rating";
import { FeedbackWithNames, EmployeeWithManager } from "@shared/schema";
import { MoreHorizontal, Eye, Edit, Trash } from "lucide-react";
import Pagination from "./pagination";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import FeedbackForm from "./feedback-form";
import { formatDate, truncateText } from "@/lib/utils";
import { Input } from "./ui/input";

interface FeedbackTableProps {
  feedback: FeedbackWithNames[];
  employees: EmployeeWithManager[];
  onDelete: (id: number) => Promise<void>;
  onUpdate: (id: number, data: Partial<FeedbackWithNames>) => Promise<void>;
}

export function FeedbackTable({ feedback, employees, onDelete, onUpdate }: FeedbackTableProps) {
  const [page, setPage] = useState(1);
  const [selectedFeedback, setSelectedFeedback] = useState<FeedbackWithNames | null>(null);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [employeeFilter, setEmployeeFilter] = useState<string>("");
  const [monthFilter, setMonthFilter] = useState<string>("");
  const [ratingFilter, setRatingFilter] = useState<string>("");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const { toast } = useToast();
  
  // Apply filters
  const filteredFeedback = feedback.filter(f => {
    // Employee filter
    if (employeeFilter && f.employeeId.toString() !== employeeFilter) {
      return false;
    }
    
    // Month filter
    if (monthFilter) {
      const feedbackDate = new Date(f.feedbackDate);
      const filterDate = monthFilter.split('-');
      const filterYear = parseInt(filterDate[0]);
      const filterMonth = parseInt(filterDate[1]) - 1; // JS months are 0-indexed
      
      if (feedbackDate.getFullYear() !== filterYear || feedbackDate.getMonth() !== filterMonth) {
        return false;
      }
    }
    
    // Rating filter
    if (ratingFilter && f.rating.toString() !== ratingFilter) {
      return false;
    }
    
    // Search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      const employeeName = f.employeeName?.toLowerCase() || '';
      const comment = f.comment.toLowerCase();
      
      return employeeName.includes(query) || comment.includes(query);
    }
    
    return true;
  });
  
  const itemsPerPage = 5;
  const totalPages = Math.ceil(filteredFeedback.length / itemsPerPage);
  const startIndex = (page - 1) * itemsPerPage;
  const paginatedFeedback = filteredFeedback.slice(startIndex, startIndex + itemsPerPage);
  
  const handleView = (feedback: FeedbackWithNames) => {
    setSelectedFeedback(feedback);
    setIsViewModalOpen(true);
  };
  
  const handleEdit = (feedback: FeedbackWithNames) => {
    setSelectedFeedback(feedback);
    setIsEditModalOpen(true);
  };
  
  const handleDelete = (feedback: FeedbackWithNames) => {
    setSelectedFeedback(feedback);
    setIsDeleteModalOpen(true);
  };
  
  const confirmDelete = async () => {
    if (!selectedFeedback) return;
    
    try {
      await onDelete(selectedFeedback.id);
      toast({
        title: "Feedback deleted",
        description: "The feedback has been successfully removed.",
        variant: "default",
      });
      setIsDeleteModalOpen(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete feedback. Please try again.",
        variant: "destructive",
      });
    }
  };
  
  const handleUpdate = async (data: Partial<FeedbackWithNames>) => {
    if (!selectedFeedback) return;
    
    try {
      await onUpdate(selectedFeedback.id, data);
      toast({
        title: "Feedback updated",
        description: "The feedback has been successfully updated.",
        variant: "default",
      });
      setIsEditModalOpen(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update feedback. Please try again.",
        variant: "destructive",
      });
    }
  };
  
  // Get unique months from feedback data
  const months = Array.from(
    new Set(
      feedback.map(f => {
        const date = new Date(f.feedbackDate);
        return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      })
    )
  ).sort().reverse();
  
  const resetFilters = () => {
    setEmployeeFilter("");
    setMonthFilter("");
    setRatingFilter("");
    setSearchQuery("");
    setPage(1);
  };
  
  return (
    <>
      <div className="bg-white rounded-lg shadow-sm overflow-hidden mb-6">
        <div className="p-4 border-b">
          <div className="flex flex-wrap gap-4 mb-4">
            <div className="relative flex-grow md:flex-grow-0">
              <Input
                placeholder="Search feedback..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full"
              />
            </div>
            
            <Select value={employeeFilter} onValueChange={setEmployeeFilter}>
              <SelectTrigger className="w-full md:w-auto">
                <SelectValue placeholder="All Employees" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Employees</SelectItem>
                {employees.map((employee) => (
                  <SelectItem key={employee.id} value={employee.id.toString()}>
                    {employee.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select value={monthFilter} onValueChange={setMonthFilter}>
              <SelectTrigger className="w-full md:w-auto">
                <SelectValue placeholder="All Months" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Months</SelectItem>
                {months.map((month) => {
                  const [year, monthNum] = month.split('-');
                  const date = new Date(parseInt(year), parseInt(monthNum) - 1);
                  const monthName = date.toLocaleString('default', { month: 'long' });
                  return (
                    <SelectItem key={month} value={month}>
                      {monthName} {year}
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
            
            <Select value={ratingFilter} onValueChange={setRatingFilter}>
              <SelectTrigger className="w-full md:w-auto">
                <SelectValue placeholder="All Ratings" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="">All Ratings</SelectItem>
                {[5, 4, 3, 2, 1].map((rating) => (
                  <SelectItem key={rating} value={rating.toString()}>
                    {rating} {rating === 1 ? 'Star' : 'Stars'}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            {(employeeFilter || monthFilter || ratingFilter || searchQuery) && (
              <Button variant="ghost" onClick={resetFilters} className="whitespace-nowrap">
                Reset Filters
              </Button>
            )}
          </div>
        </div>
        
        <Table>
          <TableHeader>
            <TableRow className="bg-neutral-light">
              <TableHead className="font-medium text-neutral-dark">Employee</TableHead>
              <TableHead className="font-medium text-neutral-dark">Date</TableHead>
              <TableHead className="font-medium text-neutral-dark">Rating</TableHead>
              <TableHead className="font-medium text-neutral-dark">Feedback</TableHead>
              <TableHead className="font-medium text-neutral-dark">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {paginatedFeedback.map((feedback) => (
              <TableRow key={feedback.id} className="border-b">
                <TableCell>
                  <div className="flex items-center">
                    <UserAvatar 
                      name={feedback.employeeName || ""}
                      className="w-8 h-8 mr-2"
                    />
                    <span>{feedback.employeeName}</span>
                  </div>
                </TableCell>
                <TableCell>{formatDate(feedback.feedbackDate)}</TableCell>
                <TableCell>
                  <StarRating rating={feedback.rating} size="sm" readOnly />
                </TableCell>
                <TableCell className="max-w-md">
                  <p className="truncate" title={feedback.comment}>
                    {truncateText(feedback.comment, 60)}
                  </p>
                </TableCell>
                <TableCell>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" className="h-8 w-8 p-0">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => handleView(feedback)}>
                        <Eye className="mr-2 h-4 w-4" />
                        <span>View Details</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleEdit(feedback)}>
                        <Edit className="mr-2 h-4 w-4" />
                        <span>Edit</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        onClick={() => handleDelete(feedback)}
                        className="text-destructive focus:text-destructive"
                      >
                        <Trash className="mr-2 h-4 w-4" />
                        <span>Delete</span>
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
            
            {paginatedFeedback.length === 0 && (
              <TableRow>
                <TableCell colSpan={5} className="text-center py-4">
                  No feedback found
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
        
        <div className="px-4 py-3 border-t flex justify-between items-center">
          <div className="text-sm text-neutral-gray">
            Showing <span className="font-medium">{filteredFeedback.length > 0 ? startIndex + 1 : 0}-{Math.min(startIndex + itemsPerPage, filteredFeedback.length)}</span> of <span className="font-medium">{filteredFeedback.length}</span> feedback entries
          </div>
          
          <Pagination
            currentPage={page}
            totalPages={totalPages}
            onPageChange={setPage}
          />
        </div>
      </div>
      
      {/* View Feedback Modal */}
      <Dialog open={isViewModalOpen} onOpenChange={setIsViewModalOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Feedback Details</DialogTitle>
          </DialogHeader>
          
          {selectedFeedback && (
            <div className="pt-4">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center">
                  <UserAvatar 
                    name={selectedFeedback.employeeName || ""}
                    className="w-12 h-12 mr-3"
                  />
                  <div>
                    <p className="font-medium text-lg">{selectedFeedback.employeeName}</p>
                    <p className="text-sm text-neutral-gray">{formatDate(selectedFeedback.feedbackDate)}</p>
                  </div>
                </div>
                <StarRating rating={selectedFeedback.rating} size="md" readOnly />
              </div>
              
              <div className="mb-4">
                <h3 className="text-sm font-medium text-neutral-gray mb-1">Feedback</h3>
                <p className="p-3 bg-neutral-light rounded-md">{selectedFeedback.comment}</p>
              </div>
              
              {selectedFeedback.areasForImprovement && (
                <div className="mb-4">
                  <h3 className="text-sm font-medium text-neutral-gray mb-1">Areas for Improvement</h3>
                  <p className="p-3 bg-neutral-light rounded-md">{selectedFeedback.areasForImprovement}</p>
                </div>
              )}
              
              {selectedFeedback.categories && (
                <div>
                  <h3 className="text-sm font-medium text-neutral-gray mb-1">Categories</h3>
                  <div className="flex flex-wrap gap-2">
                    {selectedFeedback.categories.split(',').map((category, index) => (
                      <span key={index} className="px-3 py-1 rounded-full bg-primary-light text-white text-sm">
                        {category.trim()}
                      </span>
                    ))}
                  </div>
                </div>
              )}
              
              <div className="mt-4 pt-4 border-t">
                <p className="text-sm text-neutral-gray">
                  Feedback given by <span className="font-medium">{selectedFeedback.giverName}</span>
                </p>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
      
      {/* Edit Feedback Modal */}
      <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Edit Feedback</DialogTitle>
          </DialogHeader>
          
          {selectedFeedback && (
            <FeedbackForm
              initialData={selectedFeedback}
              onSubmit={handleUpdate}
              submitLabel="Update Feedback"
              employees={employees}
              isEditing={true}
            />
          )}
        </DialogContent>
      </Dialog>
      
      {/* Delete Confirmation Modal */}
      <Dialog open={isDeleteModalOpen} onOpenChange={setIsDeleteModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Confirm Deletion</DialogTitle>
          </DialogHeader>
          
          <div className="pt-4">
            <p>
              Are you sure you want to delete this feedback for {selectedFeedback?.employeeName}? This action cannot be undone.
            </p>
            
            <div className="flex justify-end gap-2 mt-6">
              <Button
                variant="outline"
                onClick={() => setIsDeleteModalOpen(false)}
              >
                Cancel
              </Button>
              <Button
                variant="destructive"
                onClick={confirmDelete}
              >
                Delete
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

export default FeedbackTable;
