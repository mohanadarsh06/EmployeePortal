import UserAvatar from "./UserAvatar";
import StarRating from "./star-rating";
import { formatDate } from "@/lib/utils";
import { FeedbackWithNames } from "@shared/schema";

interface FeedbackItemProps {
  feedback: FeedbackWithNames;
}

export function FeedbackItem({ feedback }: FeedbackItemProps) {
  const {
    employeeName = "Unknown Employee",
    feedbackDate,
    rating,
    comment
  } = feedback;

  return (
    <div className="border-b pb-4 mb-4">
      <div className="flex justify-between items-start">
        <div className="flex items-center">
          <UserAvatar 
            name={employeeName}
            className="w-8 h-8 mr-2"
          />
          <div>
            <p className="font-medium">{employeeName}</p>
            <p className="text-xs text-neutral-gray">{formatDate(feedbackDate)}</p>
          </div>
        </div>
        <StarRating rating={rating} size="sm" readOnly />
      </div>
      <p className="text-sm mt-2">{comment}</p>
    </div>
  );
}

export default FeedbackItem;
