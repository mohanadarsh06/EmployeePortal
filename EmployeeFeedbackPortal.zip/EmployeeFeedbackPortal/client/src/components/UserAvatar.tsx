import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { getInitials } from "@/lib/utils";

interface UserAvatarProps {
  name: string;
  className?: string;
}

const UserAvatar: React.FC<UserAvatarProps> = ({ name, className }) => {
  const initials = getInitials(name);
  
  return (
    <Avatar className={className}>
      <AvatarFallback className="bg-primary-light text-white">
        {initials}
      </AvatarFallback>
    </Avatar>
  );
};

export default UserAvatar;
