import React, { useState } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import StarRating from "./star-rating";
import { FeedbackWithNames, EmployeeWithManager } from "@shared/schema";
import { formatToInputDate } from "@/lib/date-utils";
import { useAuth } from "@/hooks/use-auth";
import { Badge } from "@/components/ui/badge";

// Predefined feedback categories
const FEEDBACK_CATEGORIES = [
  "Communication",
  "Technical Skills",
  "Teamwork",
  "Leadership",
  "Problem Solving",
  "Quality",
  "Time Management",
  "Initiative",
  "Adaptability",
  "Customer Focus",
];

// Create a schema for feedback validation
const feedbackSchema = z.object({
  employeeId: z.number().min(1, { message: "Employee is required" }),
  rating: z.number().min(1, { message: "Rating is required" }).max(5),
  comment: z.string().min(5, { message: "Feedback comment is required" }),
  feedbackDate: z.string().min(1, { message: "Date is required" }),
  areasForImprovement: z.string().optional(),
  categories: z.string().optional(),
});

type FeedbackFormValues = z.infer<typeof feedbackSchema>;

interface FeedbackFormProps {
  initialData?: Partial<FeedbackWithNames>;
  onSubmit: (data: Partial<FeedbackWithNames>) => Promise<void>;
  submitLabel: string;
  employees?: EmployeeWithManager[];
  isEditing?: boolean;
}

export default function FeedbackForm({
  initialData,
  onSubmit,
  submitLabel,
  employees = [],
  isEditing = false,
}: FeedbackFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedCategories, setSelectedCategories] = useState<string[]>(
    initialData?.categories ? initialData.categories.split(',').map(c => c.trim()) : []
  );
  const { user } = useAuth();

  // Get reportees (employees who can receive feedback)
  const reportees = employees.filter(emp => 
    // When editing, allow keeping the same employee
    (isEditing && initialData?.employeeId === emp.id) ||
    // For new feedback, only show employees who can receive feedback from the current user
    (emp.managerId === user?.id)
  );

  // Initialize the form with default values
  const form = useForm<FeedbackFormValues>({
    resolver: zodResolver(feedbackSchema),
    defaultValues: {
      employeeId: initialData?.employeeId || 0,
      rating: initialData?.rating || 0,
      comment: initialData?.comment || "",
      feedbackDate: initialData?.feedbackDate 
        ? formatToInputDate(initialData.feedbackDate) 
        : formatToInputDate(new Date()),
      areasForImprovement: initialData?.areasForImprovement || "",
      categories: initialData?.categories || "",
    },
  });

  const handleSubmit = async (values: FeedbackFormValues) => {
    setIsSubmitting(true);
    try {
      // Include the categories in the form data
      const formattedValues = {
        ...values,
        categories: selectedCategories.join(', '),
        feedbackDate: new Date(values.feedbackDate),
      };
      
      await onSubmit(formattedValues);
    } finally {
      setIsSubmitting(false);
    }
  };

  const toggleCategory = (category: string) => {
    if (selectedCategories.includes(category)) {
      setSelectedCategories(selectedCategories.filter(c => c !== category));
    } else {
      setSelectedCategories([...selectedCategories, category]);
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="employeeId"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Employee</FormLabel>
              <Select
                onValueChange={(value) => field.onChange(parseInt(value))}
                value={field.value?.toString() || ""}
                disabled={isEditing}
              >
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="Select Employee" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {reportees.map((employee) => (
                    <SelectItem 
                      key={employee.id} 
                      value={employee.id.toString()}
                    >
                      {employee.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="feedbackDate"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Date</FormLabel>
              <FormControl>
                <Input type="date" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="rating"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Rating</FormLabel>
              <FormControl>
                <div className="pt-2">
                  <StarRating
                    rating={field.value}
                    onChange={field.onChange}
                    size="lg"
                    maxRating={5}
                  />
                </div>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="comment"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Feedback</FormLabel>
              <FormControl>
                <Textarea
                  placeholder="Provide detailed feedback..."
                  rows={4}
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="categories"
          render={() => (
            <FormItem>
              <FormLabel>Categories</FormLabel>
              <div className="flex flex-wrap gap-2 mt-2">
                {FEEDBACK_CATEGORIES.map((category) => (
                  <Badge 
                    key={category}
                    variant={selectedCategories.includes(category) ? "default" : "outline"}
                    className="cursor-pointer"
                    onClick={() => toggleCategory(category)}
                  >
                    {category}
                  </Badge>
                ))}
              </div>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="areasForImprovement"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Areas for Improvement</FormLabel>
              <FormControl>
                <Textarea
                  placeholder="Suggest areas for improvement..."
                  rows={3}
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="flex justify-end space-x-2 pt-4">
          <Button
            type="submit"
            disabled={isSubmitting}
          >
            {isSubmitting ? (
              <span className="flex items-center gap-1">
                <span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent"></span>
                Submitting...
              </span>
            ) : (
              submitLabel
            )}
          </Button>
        </div>
      </form>
    </Form>
  );
}

// Import the Input component in the same file to avoid circular dependencies
import { Input } from "@/components/ui/input";
