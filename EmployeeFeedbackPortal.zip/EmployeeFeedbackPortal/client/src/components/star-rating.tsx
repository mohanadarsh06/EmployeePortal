import { cn } from "@/lib/utils";
import { useState } from "react";

interface StarRatingProps {
  rating: number;
  onChange?: (rating: number) => void;
  size?: "sm" | "md" | "lg";
  readOnly?: boolean;
  maxRating?: number;
}

const StarRating: React.FC<StarRatingProps> = ({
  rating,
  onChange,
  size = "md",
  readOnly = false,
  maxRating = 5
}) => {
  const [hoverRating, setHoverRating] = useState(0);
  
  const handleClick = (index: number) => {
    if (!readOnly && onChange) {
      onChange(index);
    }
  };
  
  const handleMouseEnter = (index: number) => {
    if (!readOnly) {
      setHoverRating(index);
    }
  };
  
  const handleMouseLeave = () => {
    if (!readOnly) {
      setHoverRating(0);
    }
  };
  
  const sizeClass = {
    sm: "text-sm",
    md: "text-md",
    lg: "text-2xl"
  };
  
  return (
    <div className="flex">
      {[...Array(maxRating)].map((_, index) => {
        const starValue = index + 1;
        const filled = hoverRating ? starValue <= hoverRating : starValue <= rating;
        
        return (
          <button
            key={index}
            type="button"
            onClick={() => handleClick(starValue)}
            onMouseEnter={() => handleMouseEnter(starValue)}
            onMouseLeave={handleMouseLeave}
            className={cn(
              "p-0.5 focus:outline-none",
              readOnly ? "cursor-default" : "cursor-pointer"
            )}
            disabled={readOnly}
          >
            <span 
              className={cn(
                "material-icons",
                sizeClass[size],
                filled ? "text-status-warning" : "text-neutral-medium"
              )}
            >
              star
            </span>
          </button>
        );
      })}
    </div>
  );
};

export default StarRating;
