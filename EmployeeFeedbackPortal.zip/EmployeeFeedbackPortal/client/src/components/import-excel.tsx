import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { FileIcon, UploadIcon, XIcon, CheckIcon, AlertCircleIcon } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import * as XLSX from 'xlsx';
import { InsertEmployee } from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';

interface ImportExcelProps {
  onImportComplete: () => void;
}

export default function ImportExcel({ onImportComplete }: ImportExcelProps) {
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    
    if (selectedFile) {
      // Check if it's an Excel file
      if (!selectedFile.name.endsWith('.xlsx') && !selectedFile.name.endsWith('.xls')) {
        setError('Please upload a valid Excel file (.xlsx or .xls)');
        setFile(null);
        return;
      }
      
      setFile(selectedFile);
      setError(null);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    
    const droppedFile = e.dataTransfer.files[0];
    
    if (droppedFile) {
      // Check if it's an Excel file
      if (!droppedFile.name.endsWith('.xlsx') && !droppedFile.name.endsWith('.xls')) {
        setError('Please upload a valid Excel file (.xlsx or .xls)');
        setFile(null);
        return;
      }
      
      setFile(droppedFile);
      setError(null);
    }
  };

  const removeFile = () => {
    setFile(null);
    setError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };
  
  const processExcelFile = (file: File): Promise<InsertEmployee[]> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      
      reader.onload = (e) => {
        try {
          const data = e.target?.result;
          const workbook = XLSX.read(data, { type: 'binary' });
          const sheetName = workbook.SheetNames[0];
          const sheet = workbook.Sheets[sheetName];
          const jsonData = XLSX.utils.sheet_to_json(sheet);
          
          setProgress(50);
          
          // Transform Excel data to match our employee schema
          const employees: InsertEmployee[] = jsonData.map((row: any) => {
            return {
              name: row['Name'] || row['Employee Name'] || '',
              email: row['Email'] || `${row['Name'].toLowerCase().replace(/\s+/g, '.')}@example.com`,
              employeeId: row['Employee ID'] || row['EmpID'] || '',
              position: row['Position'] || row['Designation'] || '',
              department: row['Department'] || '',
              managerId: row['Manager ID'] || null,
              joinDate: row['Join Date'] ? new Date(row['Join Date']) : new Date(),
              isActive: true
            };
          });
          
          setProgress(75);
          
          // Validate data
          const validEmployees = employees.filter(emp => 
            emp.name && emp.employeeId && emp.position && emp.department
          );
          
          if (validEmployees.length === 0) {
            reject('No valid employee data found in the Excel file');
            return;
          }
          
          resolve(validEmployees);
        } catch (err) {
          reject('Error processing Excel file. Please check the format and try again.');
        }
      };
      
      reader.onerror = () => {
        reject('Error reading file');
      };
      
      reader.readAsBinaryString(file);
    });
  };

  const importEmployees = async () => {
    if (!file) return;
    
    setLoading(true);
    setProgress(25);
    setError(null);
    
    try {
      const employees = await processExcelFile(file);
      
      // Send to the server
      const response = await apiRequest('POST', '/api/import/employees', { employees });
      const result = await response.json();
      
      setProgress(100);
      
      toast({
        title: 'Import Successful',
        description: `Successfully imported ${result.count} employees.`,
        variant: 'default',
      });
      
      onImportComplete();
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
      toast({
        title: 'Import Failed',
        description: err instanceof Error ? err.message : String(err),
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Import Employees</CardTitle>
        <CardDescription>
          Upload an Excel file with employee data to import into the system.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div
          className={`
            border-2 border-dashed rounded-md p-6 text-center 
            ${file ? 'border-primary' : 'border-border'}
            ${loading ? 'opacity-50 pointer-events-none' : 'cursor-pointer'}
          `}
          onDragOver={handleDragOver}
          onDrop={handleDrop}
          onClick={() => fileInputRef.current?.click()}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept=".xlsx,.xls"
            onChange={handleFileChange}
            hidden
          />
          
          {!file && (
            <div className="space-y-4">
              <div className="flex justify-center">
                <UploadIcon className="h-12 w-12 text-muted-foreground" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">
                  Drag and drop your Excel file here or click to browse
                </p>
                <p className="text-xs text-muted-foreground">
                  Supports .xlsx and .xls files
                </p>
              </div>
            </div>
          )}
          
          {file && (
            <div className="flex items-center justify-between p-2">
              <div className="flex items-center space-x-3">
                <FileIcon className="h-8 w-8 text-primary" />
                <div className="text-left">
                  <p className="text-sm font-medium">{file.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {(file.size / 1024).toFixed(2)} KB
                  </p>
                </div>
              </div>
              {!loading && (
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={(e) => {
                    e.stopPropagation();
                    removeFile();
                  }}
                >
                  <XIcon className="h-4 w-4" />
                </Button>
              )}
            </div>
          )}
        </div>
        
        {error && (
          <Alert variant="destructive" className="mt-4">
            <AlertCircleIcon className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
        
        {loading && (
          <div className="mt-4 space-y-2">
            <div className="flex justify-between text-xs">
              <span>Importing...</span>
              <span>{progress}%</span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline" onClick={removeFile} disabled={!file || loading}>
          Cancel
        </Button>
        <Button onClick={importEmployees} disabled={!file || loading}>
          {loading ? (
            <span className="flex items-center gap-1">
              <span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent"></span>
              Importing...
            </span>
          ) : (
            <span className="flex items-center gap-1">
              <UploadIcon className="h-4 w-4" />
              Import Employees
            </span>
          )}
        </Button>
      </CardFooter>
    </Card>
  );
}
