import { useState } from "react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import UserAvatar from "./UserAvatar";
import { EmployeeWithManager } from "@shared/schema";
import { MoreHorizontal, Eye, Edit, Trash } from "lucide-react";
import Pagination from "./pagination";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import EmployeeForm from "./employee-form";

interface EmployeeTableProps {
  employees: EmployeeWithManager[];
  onDelete: (id: number) => Promise<void>;
  onUpdate: (id: number, data: Partial<EmployeeWithManager>) => Promise<void>;
}

export function EmployeeTable({ employees, onDelete, onUpdate }: EmployeeTableProps) {
  const [page, setPage] = useState(1);
  const [selectedEmployee, setSelectedEmployee] = useState<EmployeeWithManager | null>(null);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const { toast } = useToast();
  
  const itemsPerPage = 5;
  const totalPages = Math.ceil(employees.length / itemsPerPage);
  const startIndex = (page - 1) * itemsPerPage;
  const paginatedEmployees = employees.slice(startIndex, startIndex + itemsPerPage);
  
  const handleView = (employee: EmployeeWithManager) => {
    setSelectedEmployee(employee);
    setIsViewModalOpen(true);
  };
  
  const handleEdit = (employee: EmployeeWithManager) => {
    setSelectedEmployee(employee);
    setIsEditModalOpen(true);
  };
  
  const handleDelete = (employee: EmployeeWithManager) => {
    setSelectedEmployee(employee);
    setIsDeleteModalOpen(true);
  };
  
  const confirmDelete = async () => {
    if (!selectedEmployee) return;
    
    try {
      await onDelete(selectedEmployee.id);
      toast({
        title: "Employee deleted",
        description: `${selectedEmployee.name} has been removed.`,
        variant: "default",
      });
      setIsDeleteModalOpen(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete employee. Please try again.",
        variant: "destructive",
      });
    }
  };
  
  const handleUpdate = async (data: Partial<EmployeeWithManager>) => {
    if (!selectedEmployee) return;
    
    try {
      await onUpdate(selectedEmployee.id, data);
      toast({
        title: "Employee updated",
        description: `${selectedEmployee.name}'s information has been updated.`,
        variant: "default",
      });
      setIsEditModalOpen(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update employee. Please try again.",
        variant: "destructive",
      });
    }
  };
  
  return (
    <>
      <div className="bg-white rounded-lg shadow-sm overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-neutral-light">
              <TableHead className="font-medium text-neutral-dark">Employee Name</TableHead>
              <TableHead className="font-medium text-neutral-dark">Employee ID</TableHead>
              <TableHead className="font-medium text-neutral-dark">Position</TableHead>
              <TableHead className="font-medium text-neutral-dark">Line Manager</TableHead>
              <TableHead className="font-medium text-neutral-dark">Direct Reports</TableHead>
              <TableHead className="font-medium text-neutral-dark">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {paginatedEmployees.map((employee) => (
              <TableRow key={employee.id} className="border-b">
                <TableCell>
                  <div className="flex items-center">
                    <UserAvatar 
                      name={employee.name}
                      className="w-8 h-8 mr-2"
                    />
                    <span>{employee.name}</span>
                  </div>
                </TableCell>
                <TableCell>{employee.employeeId}</TableCell>
                <TableCell>{employee.position}</TableCell>
                <TableCell>{employee.manager?.name || "None"}</TableCell>
                <TableCell>{employee.directReports || 0}</TableCell>
                <TableCell>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" className="h-8 w-8 p-0">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => handleView(employee)}>
                        <Eye className="mr-2 h-4 w-4" />
                        <span>View Details</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleEdit(employee)}>
                        <Edit className="mr-2 h-4 w-4" />
                        <span>Edit</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        onClick={() => handleDelete(employee)}
                        className="text-destructive focus:text-destructive"
                      >
                        <Trash className="mr-2 h-4 w-4" />
                        <span>Delete</span>
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
            
            {paginatedEmployees.length === 0 && (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-4">
                  No employees found
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
        
        <div className="px-4 py-3 border-t flex justify-between items-center">
          <div className="text-sm text-neutral-gray">
            Showing <span className="font-medium">{startIndex + 1}-{Math.min(startIndex + itemsPerPage, employees.length)}</span> of <span className="font-medium">{employees.length}</span> employees
          </div>
          
          <Pagination
            currentPage={page}
            totalPages={totalPages}
            onPageChange={setPage}
          />
        </div>
      </div>
      
      {/* View Employee Modal */}
      <Dialog open={isViewModalOpen} onOpenChange={setIsViewModalOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Employee Details</DialogTitle>
          </DialogHeader>
          
          {selectedEmployee && (
            <div className="grid grid-cols-2 gap-4 pt-4">
              <div>
                <p className="text-sm text-muted-foreground">Name:</p>
                <p className="font-medium">{selectedEmployee.name}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Employee ID:</p>
                <p className="font-medium">{selectedEmployee.employeeId}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Email:</p>
                <p className="font-medium">{selectedEmployee.email}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Position:</p>
                <p className="font-medium">{selectedEmployee.position}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Department:</p>
                <p className="font-medium">{selectedEmployee.department}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Join Date:</p>
                <p className="font-medium">{new Date(selectedEmployee.joinDate).toLocaleDateString()}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Line Manager:</p>
                <p className="font-medium">{selectedEmployee.manager?.name || "None"}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Direct Reports:</p>
                <p className="font-medium">{selectedEmployee.directReports || 0}</p>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
      
      {/* Edit Employee Modal */}
      <Dialog open={isEditModalOpen} onOpenChange={setIsEditModalOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Edit Employee</DialogTitle>
          </DialogHeader>
          
          {selectedEmployee && (
            <EmployeeForm
              initialData={selectedEmployee}
              onSubmit={handleUpdate}
              submitLabel="Update Employee"
              allEmployees={employees}
            />
          )}
        </DialogContent>
      </Dialog>
      
      {/* Delete Confirmation Modal */}
      <Dialog open={isDeleteModalOpen} onOpenChange={setIsDeleteModalOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Confirm Deletion</DialogTitle>
          </DialogHeader>
          
          <div className="pt-4">
            <p>
              Are you sure you want to delete {selectedEmployee?.name}? This action cannot be undone.
            </p>
            
            {(selectedEmployee?.directReports || 0) > 0 && (
              <p className="text-destructive mt-2">
                Warning: This employee has {selectedEmployee?.directReports} direct reports. 
                Please reassign these employees first.
              </p>
            )}
            
            <div className="flex justify-end gap-2 mt-6">
              <Button
                variant="outline"
                onClick={() => setIsDeleteModalOpen(false)}
              >
                Cancel
              </Button>
              <Button
                variant="destructive"
                onClick={confirmDelete}
                disabled={(selectedEmployee?.directReports || 0) > 0}
              >
                Delete
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

export default EmployeeTable;
