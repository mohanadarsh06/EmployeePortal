import { useAuth } from "@/hooks/use-auth";
import UserAvatar from "./UserAvatar";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ChevronDown, Menu } from "lucide-react";

interface HeaderProps {
  toggleSidebar: () => void;
}

const Header: React.FC<HeaderProps> = ({ toggleSidebar }) => {
  const { user, logout } = useAuth();

  if (!user) {
    return (
      <header className="bg-primary-main text-white shadow-md">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <h1 className="text-xl font-medium">Employee Feedback Portal</h1>
        </div>
      </header>
    );
  }

  return (
    <header className="bg-primary-main text-white shadow-md">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center space-x-4">
          <button onClick={toggleSidebar} className="lg:hidden">
            <Menu size={24} />
          </button>
          <h1 className="text-xl font-medium">Employee Feedback Portal</h1>
        </div>
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="text-white py-1 px-2 h-auto">
              <div className="flex items-center space-x-2">
                <span className="hidden md:inline-block">{user.name}</span>
                <UserAvatar name={user.name} className="w-8 h-8" />
                <ChevronDown size={16} />
              </div>
            </Button>
          </DropdownMenuTrigger>
          
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>{user.name}</DropdownMenuLabel>
            <DropdownMenuLabel className="text-xs text-gray-500">{user.email}</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem>
              <span className="material-icons mr-2 text-sm">account_circle</span>
              Profile
            </DropdownMenuItem>
            <DropdownMenuItem>
              <span className="material-icons mr-2 text-sm">settings</span>
              Settings
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={logout}>
              <span className="material-icons mr-2 text-sm">logout</span>
              Logout
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
};

export default Header;
