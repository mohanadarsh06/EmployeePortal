import React from "react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

// Sample users for easy login testing
const sampleUsers = [
  { email: "sooraj@example.com", name: "Sooraj (Director)" },
  { email: "anuja@example.com", name: "Anuja (Manager)" },
  { email: "adarsh@example.com", name: "Adarsh (Developer)" },
];

export function DevLoginPanel() {
  const { login, error } = useAuth();
  const [isLoading, setIsLoading] = React.useState<Record<string, boolean>>({});

  const handleLogin = async (email: string) => {
    setIsLoading((prev) => ({ ...prev, [email]: true }));
    try {
      await login(email);
    } finally {
      setIsLoading((prev) => ({ ...prev, [email]: false }));
    }
  };

  return (
    <div className="fixed bottom-5 right-5 z-50">
      <Card className="w-80 shadow-lg border border-amber-200 bg-amber-50 dark:bg-amber-950 dark:border-amber-800">
        <CardHeader className="py-3">
          <CardTitle className="text-sm font-medium">Developer Login</CardTitle>
          <CardDescription className="text-xs">Quick login for testing</CardDescription>
        </CardHeader>
        <CardContent className="py-2">
          <div className="flex flex-col gap-2">
            {sampleUsers.map((user) => (
              <Button
                key={user.email}
                variant="outline"
                size="sm"
                className="w-full justify-start"
                disabled={isLoading[user.email]}
                onClick={() => handleLogin(user.email)}
              >
                {isLoading[user.email] ? (
                  <span className="flex items-center gap-2">
                    <span className="h-3 w-3 animate-spin rounded-full border-2 border-current border-t-transparent"></span>
                    Logging in...
                  </span>
                ) : (
                  <span>{user.name}</span>
                )}
              </Button>
            ))}
          </div>
          {error && <p className="text-xs text-red-500 mt-2">{error}</p>}
        </CardContent>
      </Card>
    </div>
  );
}