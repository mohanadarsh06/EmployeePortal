import { useLocation, Link } from "wouter";
import UserAvatar from "./UserAvatar";
import { useAuth } from "@/hooks/use-auth";
import { cn } from "@/lib/utils";

interface SidebarProps {
  open: boolean;
  onClose: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ open, onClose }) => {
  const [location] = useLocation();
  const { user } = useAuth();

  if (!user) {
    return null;
  }

  return (
    <aside 
      className={cn(
        "sidebar w-64 bg-white shadow-md transform transition-transform duration-300 lg:translate-x-0 lg:static fixed z-10 top-16 bottom-0",
        !open && "-translate-x-full"
      )}
    >
      <div className="p-4">
        <div className="flex items-center p-2 mb-6">
          <UserAvatar 
            name={user.name} 
            className="w-10 h-10 mr-3" 
          />
          <div>
            <p className="font-medium">{user.name}</p>
            <p className="text-sm text-neutral-gray">{user.position}</p>
          </div>
        </div>
        
        <nav>
          <ul>
            <li>
              <Link href="/">
                <a className={cn(
                  "flex items-center p-3 rounded-md mt-2",
                  location === "/" 
                    ? "bg-primary-light bg-opacity-10 text-primary-main font-medium" 
                    : "hover:bg-neutral-light"
                )}>
                  <span className="material-icons mr-3">dashboard</span>
                  Dashboard
                </a>
              </Link>
            </li>
            <li>
              <Link href="/employees">
                <a className={cn(
                  "flex items-center p-3 rounded-md mt-2",
                  location === "/employees" 
                    ? "bg-primary-light bg-opacity-10 text-primary-main font-medium" 
                    : "hover:bg-neutral-light"
                )}>
                  <span className="material-icons mr-3">people</span>
                  Employees
                </a>
              </Link>
            </li>
            <li>
              <Link href="/feedback">
                <a className={cn(
                  "flex items-center p-3 rounded-md mt-2",
                  location === "/feedback" 
                    ? "bg-primary-light bg-opacity-10 text-primary-main font-medium" 
                    : "hover:bg-neutral-light"
                )}>
                  <span className="material-icons mr-3">feedback</span>
                  Feedback
                </a>
              </Link>
            </li>
            <li>
              <Link href="/settings">
                <a className={cn(
                  "flex items-center p-3 rounded-md mt-2",
                  location === "/settings" 
                    ? "bg-primary-light bg-opacity-10 text-primary-main font-medium" 
                    : "hover:bg-neutral-light"
                )}>
                  <span className="material-icons mr-3">settings</span>
                  Settings
                </a>
              </Link>
            </li>
          </ul>
        </nav>
      </div>
    </aside>
  );
};

export default Sidebar;
