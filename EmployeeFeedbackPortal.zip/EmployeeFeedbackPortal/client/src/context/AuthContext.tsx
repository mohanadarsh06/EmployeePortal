import React, { createContext, useState, useEffect } from "react";
import { Employee } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

interface AuthContextType {
  user: Employee | null;
  loading: boolean;
  error: string | null;
  login: (email: string) => Promise<boolean>;
  logout: () => Promise<void>;
}

export const AuthContext = createContext<AuthContextType>({
  user: null,
  loading: true,
  error: null,
  login: async (email: string) => false,
  logout: async () => {},
});

interface AuthProviderProps {
  children: React.ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<Employee | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Check if user is already logged in from localStorage
  useEffect(() => {
    const checkAuth = async () => {
      try {
        console.log("Checking authentication status...");
        
        // First try to get user from localStorage
        const storedUser = localStorage.getItem('authUser');
        
        if (storedUser) {
          try {
            const parsedUser = JSON.parse(storedUser);
            console.log("Found user in localStorage:", parsedUser.name);
            setUser(parsedUser);
            
            // Try to validate with server as well
            try {
              const response = await fetch("/api/auth/me", {
                credentials: "include"
              });
              
              if (response.ok) {
                const userData = await response.json();
                console.log("Server validated user:", userData.name);
                setUser(userData);
              } else {
                console.log("Server could not validate user, using localStorage data");
                // Keep using localStorage data
              }
            } catch (serverErr) {
              console.log("Error checking with server, using localStorage data");
              // Keep using localStorage data
            }
          } catch (parseErr) {
            console.error("Error parsing stored user:", parseErr);
            localStorage.removeItem('authUser');
            setUser(null);
          }
        } else {
          // If no localStorage user, try server
          try {
            const response = await fetch("/api/auth/me", {
              credentials: "include"
            });
            
            if (response.ok) {
              const userData = await response.json();
              console.log("Server validated user:", userData.name);
              setUser(userData);
              localStorage.setItem('authUser', JSON.stringify(userData));
            } else {
              console.log("No authenticated user found");
              setUser(null);
              
              // Redirect to static login page for more reliability
              if (window.location.pathname !== '/login') {
                console.log("Redirecting to static login page");
                window.location.href = '/login';
              }
            }
          } catch (serverErr) {
            console.error("Error checking with server:", serverErr);
            setUser(null);
            
            // Redirect to static login page on error
            if (window.location.pathname !== '/login') {
              console.log("Error connecting to server, redirecting to static login page");
              window.location.href = '/login';
            }
          }
        }
      } catch (err) {
        console.error("Authentication check failed:", err);
        setUser(null);
      } finally {
        setLoading(false);
      }
    };

    checkAuth();
  }, []);

  const login = async (email: string) => {
    console.log("Login attempt with email:", email);
    setLoading(true);
    setError(null);

    try {
      // Simple API request
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
        credentials: "include"
      });

      if (response.ok) {
        const userData = await response.json();
        console.log("Login successful for:", userData.name);
        
        // Save to state and localStorage
        setUser(userData);
        localStorage.setItem('authUser', JSON.stringify(userData));
        
        return true;
      } else {
        const errorText = await response.text();
        console.error("Login failed:", response.status, errorText);
        
        setError(`Login failed (${response.status}): ${errorText}`);
        return false;
      }
    } catch (err) {
      console.error("Login error:", err);
      setError(err instanceof Error ? err.message : "Login failed");
      return false;
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    setLoading(true);
    
    try {
      // Clear localStorage first
      localStorage.removeItem('authUser');
      
      // Call API logout
      await fetch("/api/auth/logout", {
        method: "POST",
        credentials: "include"
      });
      
      setUser(null);
    } catch (err) {
      console.error("Logout error:", err);
      // Even if API fails, we should clear the user
      setUser(null);
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthContext.Provider value={{ user, loading, error, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};
