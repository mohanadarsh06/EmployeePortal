import { useContext, useCallback, useState, useEffect } from "react";
import { AuthContext } from "@/context/AuthContext";
import { useLocation } from "wouter";
import { Employee } from "@shared/schema";

export function useAuth() {
  const auth = useContext(AuthContext);
  const [_, setLocation] = useLocation();
  const [reportees, setReportees] = useState<Employee[]>([]);
  const [loadingReportees, setLoadingReportees] = useState(false);

  // Load reportees data when user is authenticated
  useEffect(() => {
    const fetchReportees = async () => {
      if (!auth.user) return;

      setLoadingReportees(true);
      try {
        const response = await fetch(`/api/employees`, {
          credentials: "include"
        });

        if (response.ok) {
          const employees = await response.json();
          // Filter out the current user from the reportees list
          setReportees(employees.filter((emp: Employee) => emp.id !== auth.user?.id));
        }
      } catch (error) {
        console.error("Failed to fetch reportees:", error);
      } finally {
        setLoadingReportees(false);
      }
    };

    fetchReportees();
  }, [auth.user]);

  const login = async (email: string) => {
    try {
      await auth.login(email);
      setLocation("/");
      return true;
    } catch (error) {
      console.error("Login failed:", error);
      return false;
    }
  };

  const logout = async () => {
    await auth.logout();
    setLocation("/login");
  };

  const hasAccessToEmployee = useCallback((employeeId: number) => {
    if (!auth.user) return false;
    
    // User can always access their own data
    if (auth.user.id === employeeId) return true;
    
    // Check if the employee is in the user's reportees
    return reportees.some(reportee => reportee.id === employeeId);
  }, [auth.user, reportees]);

  return {
    user: auth.user,
    loading: auth.loading || loadingReportees,
    error: auth.error,
    reportees,
    login,
    logout,
    hasAccessToEmployee,
  };
}
