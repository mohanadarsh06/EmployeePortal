import { useQuery, useMutation } from "@tanstack/react-query";
import { FeedbackWithNames, InsertFeedback } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export function useFeedback() {
  const { toast } = useToast();

  // Get all feedback
  const {
    data: feedback = [],
    isLoading,
    error,
  } = useQuery<FeedbackWithNames[]>({
    queryKey: ['/api/feedback'],
  });

  // Create feedback
  const createFeedback = useMutation({
    mutationFn: async (feedbackData: InsertFeedback) => {
      const response = await apiRequest('POST', '/api/feedback', feedbackData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/feedback'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/stats'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/recent-feedback'] });
      toast({
        title: "Success",
        description: "Feedback submitted successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to submit feedback",
        variant: "destructive",
      });
    },
  });

  // Update feedback
  const updateFeedback = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<InsertFeedback> }) => {
      const response = await apiRequest('PUT', `/api/feedback/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/feedback'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/stats'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/recent-feedback'] });
      toast({
        title: "Success",
        description: "Feedback updated successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update feedback",
        variant: "destructive",
      });
    },
  });

  // Delete feedback
  const deleteFeedback = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/feedback/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/feedback'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/stats'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/recent-feedback'] });
      toast({
        title: "Success",
        description: "Feedback deleted successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete feedback",
        variant: "destructive",
      });
    },
  });

  // Get feedback by ID
  const getFeedback = async (id: number): Promise<FeedbackWithNames | null> => {
    try {
      const response = await fetch(`/api/feedback/${id}`, {
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error("Failed to fetch feedback");
      }
      
      return await response.json();
    } catch (error) {
      console.error("Error fetching feedback:", error);
      return null;
    }
  };

  return {
    feedback,
    isLoading,
    error,
    createFeedback,
    updateFeedback,
    deleteFeedback,
    getFeedback,
  };
}
