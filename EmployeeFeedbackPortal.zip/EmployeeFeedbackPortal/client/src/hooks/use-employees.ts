import { useQuery, useMutation } from "@tanstack/react-query";
import { Employee, EmployeeWithManager, InsertEmployee } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export function useEmployees() {
  const { toast } = useToast();

  // Get all employees
  const {
    data: employees = [],
    isLoading,
    error,
  } = useQuery<EmployeeWithManager[]>({
    queryKey: ['/api/employees'],
  });

  // Create employee
  const createEmployee = useMutation({
    mutationFn: async (employee: InsertEmployee) => {
      const response = await apiRequest('POST', '/api/employees', employee);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/employees'] });
      toast({
        title: "Success",
        description: "Employee created successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to create employee",
        variant: "destructive",
      });
    },
  });

  // Update employee
  const updateEmployee = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<Employee> }) => {
      const response = await apiRequest('PUT', `/api/employees/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/employees'] });
      toast({
        title: "Success",
        description: "Employee updated successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update employee",
        variant: "destructive",
      });
    },
  });

  // Delete employee
  const deleteEmployee = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/employees/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/employees'] });
      toast({
        title: "Success",
        description: "Employee deleted successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete employee",
        variant: "destructive",
      });
    },
  });

  // Get employee by ID
  const getEmployee = async (id: number): Promise<EmployeeWithManager | null> => {
    try {
      const response = await fetch(`/api/employees/${id}`, {
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error("Failed to fetch employee");
      }
      
      return await response.json();
    } catch (error) {
      console.error("Error fetching employee:", error);
      return null;
    }
  };

  return {
    employees,
    isLoading,
    error,
    createEmployee,
    updateEmployee,
    deleteEmployee,
    getEmployee,
  };
}
