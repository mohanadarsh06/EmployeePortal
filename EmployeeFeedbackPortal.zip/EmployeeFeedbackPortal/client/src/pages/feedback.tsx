import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import FeedbackTable from "@/components/feedback-table";
import FeedbackForm from "@/components/feedback-form";
import { SearchIcon, PlusCircle, SlidersHorizontal } from "lucide-react";
import { FeedbackWithNames, EmployeeWithManager } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Feedback() {
  const [searchQuery, setSearchQuery] = useState("");
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const { toast } = useToast();
  
  // Fetch feedback data
  const { data: feedbackData = [], isLoading: feedbackLoading } = useQuery<FeedbackWithNames[]>({
    queryKey: ['/api/feedback'],
  });
  
  // Fetch employees data for dropdowns
  const { data: employees = [], isLoading: employeesLoading } = useQuery<EmployeeWithManager[]>({
    queryKey: ['/api/employees'],
  });
  
  // Delete feedback mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/feedback/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/feedback'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/stats'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/recent-feedback'] });
      toast({
        title: "Success",
        description: "Feedback deleted successfully",
      });
    }
  });
  
  // Update feedback mutation
  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<FeedbackWithNames> }) => {
      await apiRequest('PUT', `/api/feedback/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/feedback'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/stats'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/recent-feedback'] });
      toast({
        title: "Success",
        description: "Feedback updated successfully",
      });
    }
  });
  
  // Create feedback mutation
  const createMutation = useMutation({
    mutationFn: async (data: Partial<FeedbackWithNames>) => {
      await apiRequest('POST', '/api/feedback', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/feedback'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/stats'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/recent-feedback'] });
      setIsAddModalOpen(false);
      toast({
        title: "Success",
        description: "Feedback added successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to add feedback: ${error instanceof Error ? error.message : 'Unknown error'}`,
        variant: "destructive",
      });
    }
  });
  
  const handleDelete = async (id: number) => {
    await deleteMutation.mutateAsync(id);
  };
  
  const handleUpdate = async (id: number, data: Partial<FeedbackWithNames>) => {
    await updateMutation.mutateAsync({ id, data });
  };
  
  const handleCreate = async (data: Partial<FeedbackWithNames>) => {
    await createMutation.mutateAsync(data);
  };
  
  const isLoading = feedbackLoading || employeesLoading;
  
  if (isLoading) {
    return (
      <div className="flex flex-col gap-6">
        <div className="mb-6 flex justify-between items-center">
          <h2 className="text-2xl font-medium">Feedback</h2>
        </div>
        
        <div className="animate-pulse bg-white rounded-lg shadow-sm h-96"></div>
      </div>
    );
  }
  
  return (
    <div className="flex flex-col gap-6">
      <div className="mb-6 flex justify-between items-center">
        <h2 className="text-2xl font-medium">Feedback</h2>
        <div className="flex space-x-2">
          <div className="relative">
            <Input
              type="text"
              placeholder="Search feedback..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 w-full md:w-auto min-w-[200px]"
            />
            <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          </div>
          <Button 
            onClick={() => setIsAddModalOpen(true)}
            className="whitespace-nowrap"
          >
            <PlusCircle className="h-4 w-4 mr-2" />
            Give Feedback
          </Button>
          <Button variant="outline" size="icon">
            <SlidersHorizontal className="h-4 w-4" />
          </Button>
        </div>
      </div>
      
      <FeedbackTable
        feedback={feedbackData}
        employees={employees}
        onDelete={handleDelete}
        onUpdate={handleUpdate}
      />
      
      {/* Add Feedback Modal */}
      <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Give Feedback</DialogTitle>
          </DialogHeader>
          
          <FeedbackForm
            onSubmit={handleCreate}
            submitLabel="Submit Feedback"
            employees={employees}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}
