import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";

// Sample logins with role information
const sampleLogins = [
  { 
    email: "sooraj@example.com", 
    name: "Sooraj Kumar", 
    role: "Director",
    description: "Top-level manager, can see all employees" 
  },
  { 
    email: "anuja@example.com", 
    name: "Anuja S", 
    role: "Manager",
    description: "Mid-level manager, reports to Sooraj" 
  },
  { 
    email: "adarsh@example.com", 
    name: "Adarsh R", 
    role: "Developer",
    description: "Reports to Anuja" 
  },
  { 
    email: "vinod@example.com", 
    name: "Vinod K", 
    role: "QA Engineer",
    description: "Reports to Sooraj" 
  },
  { 
    email: "asha@example.com", 
    name: "Asha M", 
    role: "Designer",
    description: "Reports to Sooraj" 
  }
];

export default function Login() {
  const { login, error } = useAuth();
  const [loginState, setLoginState] = useState<{loading: boolean, email: string | null}>({
    loading: false,
    email: null
  });

  // Login handler
  const handleLogin = async (email: string) => {
    setLoginState({loading: true, email});
    
    try {
      console.log("Attempting login with:", email);
      await login(email);
    } catch (err) {
      console.error("Login error:", err);
    } finally {
      setLoginState({loading: false, email: null});
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background to-muted p-4">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="pb-4">
          <CardTitle className="text-2xl font-bold text-center">Employee Feedback Portal</CardTitle>
          <CardDescription className="text-center">
            Select a user to sign in as
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-6">
          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Sign in as:</h3>
            
            {sampleLogins.map((user) => (
              <div key={user.email} className="rounded-lg border border-muted p-4 hover:bg-muted/50 transition-colors">
                <Button
                  variant="ghost"
                  className="w-full justify-start px-0 text-left"
                  onClick={() => handleLogin(user.email)}
                  disabled={loginState.loading}
                >
                  <div className="flex flex-col items-start">
                    <div className="text-lg font-medium">
                      {user.name}
                      <span className="ml-2 text-sm font-normal text-muted-foreground">
                        ({user.role})
                      </span>
                    </div>
                    <div className="text-sm text-muted-foreground">{user.email}</div>
                    <div className="text-xs mt-1 text-muted-foreground">{user.description}</div>
                  </div>
                </Button>
                
                {loginState.loading && loginState.email === user.email && (
                  <div className="flex items-center justify-center mt-2">
                    <span className="h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent mr-2"></span>
                    <span className="text-sm text-muted-foreground">Signing in...</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
        
        <CardFooter className="flex flex-col">
          <Separator className="mb-4" />
          <p className="text-sm text-center text-muted-foreground">
            Select any user to explore the application. Each user has different permissions based on their position in the hierarchy.
          </p>
        </CardFooter>
      </Card>
    </div>
  );
}