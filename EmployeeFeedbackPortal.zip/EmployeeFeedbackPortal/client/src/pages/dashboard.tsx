import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FeedbackWithNames } from "@shared/schema";
import FeedbackItem from "@/components/feedback-item";
import { 
  TeamMembersCard, 
  FeedbackGivenCard, 
  PendingFeedbackCard, 
  AvgScoreCard 
} from "@/components/stat-card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { CalendarIcon, FileDownIcon } from "lucide-react";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { formatDate } from "@/lib/utils";

interface DashboardStats {
  teamMembers: number;
  feedbackGiven: number;
  pendingFeedback: number;
  avgScore: string;
}

export default function Dashboard() {
  const [selectedMonth, setSelectedMonth] = useState(() => {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  });
  
  // Fetch dashboard stats
  const { data: stats, isLoading: statsLoading } = useQuery<DashboardStats>({
    queryKey: ['/api/dashboard/stats'],
  });
  
  // Fetch recent feedback
  const { data: recentFeedback, isLoading: feedbackLoading } = useQuery<FeedbackWithNames[]>({
    queryKey: ['/api/dashboard/recent-feedback'],
  });
  
  // Generate chart data
  const generateChartData = () => {
    if (!recentFeedback) return [];
    
    // Group feedback by month
    const feedbackByMonth: Record<string, { count: number; ratings: number[] }> = {};
    
    recentFeedback.forEach(feedback => {
      const date = new Date(feedback.feedbackDate);
      const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      
      if (!feedbackByMonth[monthKey]) {
        feedbackByMonth[monthKey] = { count: 0, ratings: [] };
      }
      
      feedbackByMonth[monthKey].count += 1;
      feedbackByMonth[monthKey].ratings.push(feedback.rating);
    });
    
    // Convert to chart data format
    return Object.entries(feedbackByMonth).map(([month, data]) => {
      const [year, monthNum] = month.split('-');
      const date = new Date(parseInt(year), parseInt(monthNum) - 1);
      const monthName = date.toLocaleString('default', { month: 'short' });
      
      const avgRating = data.ratings.length > 0
        ? data.ratings.reduce((sum, r) => sum + r, 0) / data.ratings.length
        : 0;
      
      return {
        month: `${monthName} ${year}`,
        count: data.count,
        avgRating: parseFloat(avgRating.toFixed(1)),
      };
    }).sort((a, b) => {
      const monthA = new Date(a.month).getTime();
      const monthB = new Date(b.month).getTime();
      return monthA - monthB;
    });
  };
  
  const chartData = generateChartData();
  
  // Get available months for the dropdown
  const availableMonths = Array.from(
    new Set(
      (recentFeedback || []).map(f => {
        const date = new Date(f.feedbackDate);
        return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      })
    )
  ).sort().reverse();
  
  // Add current month if not in the list
  const currentMonth = (() => {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  })();
  
  if (!availableMonths.includes(currentMonth)) {
    availableMonths.unshift(currentMonth);
  }
  
  // Loading states
  if (statsLoading || feedbackLoading) {
    return (
      <div className="flex flex-col gap-6">
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-medium">Dashboard</h2>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6 mb-8">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-16 bg-neutral-light rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="col-span-2 animate-pulse">
            <CardHeader>
              <CardTitle className="h-6 w-24 bg-neutral-light rounded"></CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-64 bg-neutral-light rounded"></div>
            </CardContent>
          </Card>
          
          <Card className="animate-pulse">
            <CardHeader>
              <CardTitle className="h-6 w-32 bg-neutral-light rounded"></CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="h-24 bg-neutral-light rounded"></div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }
  
  return (
    <div className="flex flex-col gap-6">
      <div className="mb-6 flex justify-between items-center">
        <h2 className="text-2xl font-medium">Dashboard</h2>
        <div className="flex space-x-2">
          <Select value={selectedMonth} onValueChange={setSelectedMonth}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select month" />
            </SelectTrigger>
            <SelectContent>
              {availableMonths.map((month) => {
                const [year, monthNum] = month.split('-');
                const date = new Date(parseInt(year), parseInt(monthNum) - 1);
                const monthName = date.toLocaleString('default', { month: 'long' });
                
                return (
                  <SelectItem key={month} value={month}>
                    {monthName} {year}
                  </SelectItem>
                );
              })}
            </SelectContent>
          </Select>
          
          <Button className="flex items-center gap-1">
            <FileDownIcon className="h-4 w-4" />
            Export
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6 mb-8">
        <TeamMembersCard value={stats?.teamMembers || 0} />
        <FeedbackGivenCard value={stats?.feedbackGiven || 0} />
        <PendingFeedbackCard value={stats?.pendingFeedback || 0} />
        <AvgScoreCard value={stats?.avgScore || "0.0/5"} />
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="col-span-2">
          <CardHeader>
            <CardTitle>Team Activity</CardTitle>
          </CardHeader>
          <CardContent>
            {chartData.length > 0 ? (
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={chartData}
                    margin={{ top: 20, right: 30, left: 20, bottom: 20 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip
                      formatter={(value, name) => {
                        if (name === 'count') return [`${value} feedbacks`, 'Feedbacks'];
                        if (name === 'avgRating') return [`${value}/5`, 'Avg Rating'];
                        return [value, name];
                      }}
                    />
                    <Bar dataKey="count" name="Feedbacks" fill="hsl(var(--chart-1))">
                      {chartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill="hsl(var(--chart-1))" />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="h-64 flex items-center justify-center text-neutral-gray">
                <div className="text-center">
                  <span className="material-icons text-4xl">insights</span>
                  <p className="mt-2">No feedback data available to display</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex justify-between items-center pb-2">
            <CardTitle>Recent Feedback</CardTitle>
            <Button variant="link" className="p-0 h-auto text-primary text-sm">
              View All
            </Button>
          </CardHeader>
          <CardContent>
            {recentFeedback && recentFeedback.length > 0 ? (
              recentFeedback.map((feedback) => (
                <FeedbackItem key={feedback.id} feedback={feedback} />
              ))
            ) : (
              <div className="text-center py-8 text-neutral-gray">
                <span className="material-icons text-4xl">comment</span>
                <p className="mt-2">No recent feedback available</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
