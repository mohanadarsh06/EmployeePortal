import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import EmployeeTable from "@/components/employee-table";
import EmployeeForm from "@/components/employee-form";
import ImportExcel from "@/components/import-excel";
import { SearchIcon, UserPlusIcon, Upload, SlidersHorizontal } from "lucide-react";
import { EmployeeWithManager } from "@shared/schema";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Employees() {
  const [searchQuery, setSearchQuery] = useState("");
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const { toast } = useToast();
  
  // Fetch employees data
  const { data: employees = [], isLoading } = useQuery<EmployeeWithManager[]>({
    queryKey: ['/api/employees'],
  });
  
  // Filter employees based on search query
  const filteredEmployees = employees.filter(
    (employee) =>
      employee.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      employee.employeeId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      employee.position.toLowerCase().includes(searchQuery.toLowerCase()) ||
      employee.department.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  // Delete employee mutation
  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/employees/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/employees'] });
    }
  });
  
  // Update employee mutation
  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<EmployeeWithManager> }) => {
      await apiRequest('PUT', `/api/employees/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/employees'] });
    }
  });
  
  // Create employee mutation
  const createMutation = useMutation({
    mutationFn: async (data: Partial<EmployeeWithManager>) => {
      await apiRequest('POST', '/api/employees', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/employees'] });
      setIsAddModalOpen(false);
      toast({
        title: "Success",
        description: "Employee added successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to add employee: ${error instanceof Error ? error.message : 'Unknown error'}`,
        variant: "destructive",
      });
    }
  });
  
  const handleDelete = async (id: number) => {
    await deleteMutation.mutateAsync(id);
  };
  
  const handleUpdate = async (id: number, data: Partial<EmployeeWithManager>) => {
    await updateMutation.mutateAsync({ id, data });
  };
  
  const handleCreate = async (data: Partial<EmployeeWithManager>) => {
    await createMutation.mutateAsync(data);
  };
  
  const handleImportComplete = () => {
    queryClient.invalidateQueries({ queryKey: ['/api/employees'] });
    setIsImportModalOpen(false);
  };
  
  if (isLoading) {
    return (
      <div className="flex flex-col gap-6">
        <div className="mb-6 flex justify-between items-center">
          <h2 className="text-2xl font-medium">Employees</h2>
        </div>
        
        <div className="animate-pulse bg-white rounded-lg shadow-sm h-96"></div>
      </div>
    );
  }
  
  return (
    <div className="flex flex-col gap-6">
      <div className="mb-6 flex justify-between items-center">
        <h2 className="text-2xl font-medium">Employees</h2>
        <div className="flex space-x-2">
          <div className="relative">
            <Input
              type="text"
              placeholder="Search employees..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 w-full md:w-auto min-w-[200px]"
            />
            <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          </div>
          <Button 
            onClick={() => setIsAddModalOpen(true)}
            className="whitespace-nowrap"
          >
            <UserPlusIcon className="h-4 w-4 mr-2" />
            Add Employee
          </Button>
          <Button 
            onClick={() => setIsImportModalOpen(true)} 
            variant="outline"
            className="whitespace-nowrap"
          >
            <Upload className="h-4 w-4 mr-2" />
            Import
          </Button>
          <Button variant="outline" size="icon">
            <SlidersHorizontal className="h-4 w-4" />
          </Button>
        </div>
      </div>
      
      <EmployeeTable
        employees={filteredEmployees}
        onDelete={handleDelete}
        onUpdate={handleUpdate}
      />
      
      {/* Add Employee Modal */}
      <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Add New Employee</DialogTitle>
          </DialogHeader>
          
          <EmployeeForm
            onSubmit={handleCreate}
            submitLabel="Add Employee"
            allEmployees={employees}
          />
        </DialogContent>
      </Dialog>
      
      {/* Import Excel Modal */}
      <Dialog open={isImportModalOpen} onOpenChange={setIsImportModalOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Import Employees</DialogTitle>
          </DialogHeader>
          
          <ImportExcel onImportComplete={handleImportComplete} />
        </DialogContent>
      </Dialog>
    </div>
  );
}
