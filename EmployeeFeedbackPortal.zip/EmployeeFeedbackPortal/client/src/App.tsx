import { Switch, Route, useLocation } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Layout from "@/components/Layout";
import Dashboard from "@/pages/dashboard";
import Employees from "@/pages/employees";
import Feedback from "@/pages/feedback";
import Settings from "@/pages/settings";
import Login from "@/pages/login";
import { useAuth } from "@/hooks/use-auth";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { DevLoginPanel } from "@/components/DevLoginPanel";

function AuthRouter() {
  const { user, loading, login } = useAuth();
  const [location, setLocation] = useLocation();
  const [debugMode, setDebugMode] = useState(false);
  
  // Auto login for testing (debug mode)
  useEffect(() => {
    if (debugMode && !loading && !user) {
      console.log("Debug mode - auto login");
      login("sooraj@example.com").then(success => {
        console.log("Auto login result:", success);
      });
    }
  }, [debugMode, loading, user, login]);

  // If not authenticated and not loading, redirect to login
  useEffect(() => {
    if (!loading && !user && location !== "/login") {
      console.log("Not authenticated, redirecting to login");
      setLocation("/login");
    }
  }, [user, loading, location, setLocation]);

  // If authenticated and on login page, redirect to dashboard
  useEffect(() => {
    if (user && location === "/login") {
      console.log("Already authenticated, redirecting to dashboard");
      setLocation("/");
    }
  }, [user, location, setLocation]);

  if (loading) {
    return (
      <div className="h-screen w-full flex items-center justify-center flex-col">
        <div className="animate-spin h-10 w-10 rounded-full border-4 border-primary border-t-transparent mb-4"></div>
        <div className="text-primary">Loading application...</div>
        
        {/* Debug button */}
        <Button 
          variant="outline" 
          size="sm" 
          className="mt-8" 
          onClick={() => setDebugMode(prev => !prev)}
        >
          {debugMode ? "Disable Debug Mode" : "Enable Debug Mode"}
        </Button>
      </div>
    );
  }

  // If not authenticated, show login
  if (!user) {
    return (
      <Switch>
        <Route path="/login" component={Login} />
        <Route path="/" component={Login} />
        <Route>
          {() => {
            setLocation("/login");
            return null;
          }}
        </Route>
      </Switch>
    );
  }

  // User is authenticated
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/employees" component={Employees} />
        <Route path="/feedback" component={Feedback} />
        <Route path="/settings" component={Settings} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  const [showDevLogin, setShowDevLogin] = useState(true);
  
  // Handle keyboard shortcut Ctrl+Shift+D to toggle dev login panel
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.shiftKey && e.key === 'D') {
        setShowDevLogin(prev => !prev);
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);
  
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <AuthRouter />
        {showDevLogin && <DevLoginPanel />}
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
