# Excel Import Functionality for Employee Feedback Portal

## Overview

The Employee Feedback Portal includes a feature to import employee data from Excel files, both through the web interface and during application initialization. This document explains how to use this feature effectively.

## Excel Template Format

The Excel file should contain the following columns:

1. **name** (required): Employee's full name
2. **email** (required): Employee's email address
3. **employee_id** (required): Unique employee identifier
4. **position** (required): Job title or role
5. **department** (required): Department or team
6. **manager_id** (optional): ID of the employee's manager (numeric value)
7. **join_date** (optional): Date the employee joined (YYYY-MM-DD format)
8. **is_active** (optional): Whether the employee is active (TRUE/FALSE)

Example:

| name      | email              | employee_id | position         | department  | manager_id | join_date  | is_active |
|-----------|--------------------|--------------|--------------------|-------------|------------|------------|-----------|
| John Doe  | john@example.com   | EMP001       | Software Engineer | Engineering | 1          | 2023-01-15 | TRUE      |
| Jane Smith| jane@example.com   | EMP002       | Designer          | Design      | 1          | 2023-02-20 | TRUE      |

## Using Excel Import in the Web Interface

1. Log in to the Employee Feedback Portal
2. Navigate to the Employees page
3. Click the "Import from Excel" button
4. Click "Download Template" to get a sample Excel file with the correct structure
5. Fill in your employee data in the downloaded template
6. Upload the completed Excel file through the import form
7. Review the import results

## Using Excel Import During Application Initialization

You can also import employees from an Excel file when the application starts up:

1. Set the `EXCEL_IMPORT_PATH` environment variable to the absolute path of your Excel file
2. Start or restart the application
3. Check the application logs for import results

Example:

```bash
export EXCEL_IMPORT_PATH=/path/to/employees.xlsx
python run.py
```

## Notes and Limitations

1. The import process will only add new employees; it won't update existing ones
2. Email addresses and employee IDs must be unique
3. If a manager ID is provided, it must reference an existing employee ID or be left blank
4. For web interface imports, the maximum file size is 10MB
5. The Excel import during initialization only occurs if the database is empty

## Troubleshooting

If you encounter errors during import:

1. Check that all required fields (name, email, employee_id, position, department) are filled in
2. Ensure email addresses and employee IDs are unique
3. Verify that manager IDs reference existing employees
4. Check that the Excel file follows the correct format with headers in the first row

For more detailed error information, check the application logs or review the error messages displayed in the web interface after import.