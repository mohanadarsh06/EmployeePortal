import { pgTable, text, serial, integer, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Employee schema
export const employees = pgTable("employees", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  employeeId: text("employee_id").notNull().unique(),
  position: text("position").notNull(),
  department: text("department").notNull(),
  managerId: integer("manager_id").references(() => employees.id, { onDelete: "set null" }),
  joinDate: timestamp("join_date").notNull(),
  isActive: boolean("is_active").notNull().default(true),
});

// Feedback schema
export const feedbacks = pgTable("feedbacks", {
  id: serial("id").primaryKey(),
  employeeId: integer("employee_id").notNull().references(() => employees.id, { onDelete: "cascade" }),
  giverId: integer("giver_id").notNull().references(() => employees.id, { onDelete: "cascade" }),
  rating: integer("rating").notNull(),
  comment: text("comment").notNull(),
  feedbackDate: timestamp("feedback_date").notNull(),
  areasForImprovement: text("areas_for_improvement"),
  categories: text("categories"),
});

// Insert schemas
export const insertEmployeeSchema = createInsertSchema(employees).omit({ id: true });
export const insertFeedbackSchema = createInsertSchema(feedbacks).omit({ id: true });

// Types
export type Employee = typeof employees.$inferSelect;
export type InsertEmployee = z.infer<typeof insertEmployeeSchema>;
export type Feedback = typeof feedbacks.$inferSelect;
export type InsertFeedback = z.infer<typeof insertFeedbackSchema>;

// Enhanced types for frontend usage
export interface EmployeeWithManager extends Employee {
  manager?: Employee;
  directReports?: number;
}

export interface FeedbackWithNames extends Feedback {
  employeeName?: string;
  giverName?: string;
  employeeInitials?: string;
}

// Extends for validation
export const loginSchema = z.object({
  email: z.string().email("Invalid email format"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

export type LoginCredentials = z.infer<typeof loginSchema>;
