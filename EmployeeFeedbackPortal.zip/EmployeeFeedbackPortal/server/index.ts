import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { seed } from "./seed";
import path from "path";
import { createProxyMiddleware } from "http-proxy-middleware";
import { spawn } from "child_process";

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use((req, res, next) => {
  const start = Date.now();
  const reqPath = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (reqPath.startsWith("/api")) {
      let logLine = `${req.method} ${reqPath} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

// Function to start the Python Flask app
const startFlaskApp = () => {
  console.log('Starting Flask application...');
  
  // Start the Flask application
  const flaskApp = spawn('python', ['run.py']);
  
  flaskApp.stdout.on('data', (data: Buffer) => {
    console.log(`Flask stdout: ${data}`);
  });
  
  flaskApp.stderr.on('data', (data: Buffer) => {
    console.error(`Flask stderr: ${data}`);
  });
  
  flaskApp.on('close', (code: number) => {
    console.log(`Flask process exited with code ${code}`);
  });
  
  // Make sure to kill the Flask process when this Node.js process exits
  process.on('exit', () => {
    console.log('Killing Flask process...');
    flaskApp.kill();
  });
  
  // Handle signals properly
  process.on('SIGINT', () => {
    console.log('Received SIGINT. Killing Flask process...');
    flaskApp.kill();
    process.exit(0);
  });
  
  process.on('SIGTERM', () => {
    console.log('Received SIGTERM. Killing Flask process...');
    flaskApp.kill();
    process.exit(0);
  });
}

(async () => {
  // Start the Flask app
  startFlaskApp();
  
  // Seed the database with initial data
  try {
    await seed();
  } catch (error) {
    console.error("Error seeding database:", error);
  }
  
  const server = await registerRoutes(app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // Create a special healthcheck endpoint to check if the server is running
  app.get("/health", (_req, res) => {
    res.status(200).send("Server is running");
  });

  // Very explicit route for root path, must come before static middleware
  app.get('/', (req, res) => {
    console.log('Serving direct login page for root path');
    res.sendFile(path.resolve('./client/direct-login.html'));
  });
  
  // Serve static assets from the client directory
  app.use(express.static('client'));
  
  // Dashboard route - serve the dashboard HTML file
  app.get('/dashboard.html', (req, res) => {
    console.log('Serving dashboard page');
    res.sendFile(path.resolve('./client/dashboard.html'));
  });
  
  // Employees route - serve the employees HTML file
  app.get('/employees.html', (req, res) => {
    console.log('Serving employees page');
    res.sendFile(path.resolve('./client/employees.html'));
  });
  
  // Feedback route - serve the feedback HTML file
  app.get('/feedback.html', (req, res) => {
    console.log('Serving feedback page');
    res.sendFile(path.resolve('./client/feedback.html'));
  });
  
  // Proxy to Python Flask application on port 5001
  // Proxy for /python path
  app.use("/python", createProxyMiddleware({
    target: "http://127.0.0.1:5001",
    changeOrigin: true,
    pathRewrite: {
      '^/python': '/'
    },
    onProxyReq: (proxyReq, req, res) => {
      console.log(`Proxying request to Flask: ${req.method} ${req.path}`);
    }
  }));

  // Proxy for /api path - needed for Flask API endpoints
  app.use("/api", createProxyMiddleware({
    target: "http://127.0.0.1:5001",
    changeOrigin: true,
    onProxyReq: (proxyReq, req, res) => {
      console.log(`Proxying API request to Flask: ${req.method} ${req.path}`);
    }
  }));

  // Handle all other routes with the direct login page
  app.get(/^(?!\/python).*/, (req, res) => {
    console.log(`Serving direct-login.html for path: ${req.path}`);
    res.sendFile(path.resolve('./client/direct-login.html'));
  });
  
  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // ALWAYS serve the app on port 5000
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = 5000;
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true,
  }, () => {
    log(`serving on port ${port}`);
  });
})();
