import { db } from "./db";
import * as schema from "@shared/schema";
import { sql } from "drizzle-orm";

async function seed() {
  console.log("Seeding database with initial data...");

  try {
    // Check if we already have data
    const result = await db.$client.query('SELECT count(*) FROM employees');
    const count = parseInt(result.rows[0].count);
    
    if (count > 0) {
      console.log("Database already has data, skipping seed");
      return;
    }

    // Add sample employees
    const sooraj = await db.insert(schema.employees).values({
      name: "Sooraj Kumar",
      email: "sooraj@example.com",
      employeeId: "EMP001",
      position: "Senior Manager",
      department: "Engineering",
      managerId: null,
      joinDate: new Date("2020-01-02"),
      isActive: true
    }).returning().then(res => res[0]);

    const anuja = await db.insert(schema.employees).values({
      name: "Anuja S",
      email: "anuja@example.com",
      employeeId: "EMP002",
      position: "Manager",
      department: "Engineering",
      managerId: sooraj.id,
      joinDate: new Date("2020-02-03"),
      isActive: true
    }).returning().then(res => res[0]);

    const adarsh = await db.insert(schema.employees).values({
      name: "Adarsh R",
      email: "adarsh@example.com",
      employeeId: "EMP003",
      position: "Developer",
      department: "Engineering",
      managerId: anuja.id,
      joinDate: new Date("2021-03-04"),
      isActive: true
    }).returning().then(res => res[0]);

    const vinod = await db.insert(schema.employees).values({
      name: "Vinod K",
      email: "vinod@example.com",
      employeeId: "EMP004",
      position: "QA Engineer",
      department: "QA",
      managerId: sooraj.id,
      joinDate: new Date("2021-06-05"),
      isActive: true
    }).returning().then(res => res[0]);

    const asha = await db.insert(schema.employees).values({
      name: "Asha M",
      email: "asha@example.com",
      employeeId: "EMP005",
      position: "Designer",
      department: "Design",
      managerId: sooraj.id,
      joinDate: new Date("2022-01-06"),
      isActive: true
    }).returning().then(res => res[0]);

    // Add sample feedback
    await db.insert(schema.feedbacks).values({
      employeeId: adarsh.id, // Adarsh
      giverId: anuja.id,    // Anuja (Manager)
      rating: 4,
      feedbackDate: new Date("2023-10-15"),
      comment: "Adarsh has shown excellent problem-solving skills and consistently delivers high-quality code. He's been instrumental in our recent project delivery.",
      areasForImprovement: "Should work on better documentation and knowledge sharing with the team.",
      categories: "Technical Skills, Quality"
    });

    await db.insert(schema.feedbacks).values({
      employeeId: adarsh.id, // Adarsh
      giverId: anuja.id,    // Anuja (Manager)
      rating: 3,
      feedbackDate: new Date("2023-07-20"),
      comment: "Adarsh's performance has been satisfactory this quarter. He completes assigned tasks on time.",
      areasForImprovement: "Needs to improve communication with team members and take more initiative.",
      categories: "Communication, Initiative"
    });

    await db.insert(schema.feedbacks).values({
      employeeId: anuja.id, // Anuja
      giverId: sooraj.id,    // Sooraj (Manager)
      rating: 5,
      feedbackDate: new Date("2023-09-10"),
      comment: "Anuja is an exceptional manager who consistently guides her team to excellent results. Her leadership during the challenging XYZ project was outstanding.",
      areasForImprovement: "Could delegate more tasks to develop team members' skills.",
      categories: "Leadership, Management"
    });

    console.log("Database seeded successfully with sample data!");
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}

export { seed };