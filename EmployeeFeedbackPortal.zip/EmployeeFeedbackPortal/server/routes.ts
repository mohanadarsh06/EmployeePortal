import express, { Request, Response, NextFunction } from "express";
import type { Express } from "express";
import { createServer, type Server } from "http";
// Import our session types
import './types';
import { storage } from "./storage";
import { z } from "zod";
import { insertEmployeeSchema, insertFeedbackSchema } from "@shared/schema";
import session from "express-session";
import MemoryStore from "memorystore";

export async function registerRoutes(app: Express): Promise<Server> {
  // Enable CORS for all routes during development
  app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    
    if (req.method === 'OPTIONS') {
      return res.sendStatus(200);
    }
    
    next();
  });
  // Set up session middleware for authentication
  const MemStoreSession = MemoryStore(session);
  app.use(
    session({
      secret: process.env.SESSION_SECRET || "my-secret-key",
      resave: false,
      saveUninitialized: false,
      cookie: { secure: process.env.NODE_ENV === "production", maxAge: 24 * 60 * 60 * 1000 },
      store: new MemStoreSession({
        checkPeriod: 86400000 // prune expired entries every 24h
      })
    })
  );

  // Authentication middleware
  const requireAuth = (req: Request, res: Response, next: Function) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Authentication required" });
    }
    next();
  };

  // Authorization middleware - check if user can access employee data
  const canAccessEmployee = async (req: Request, res: Response, next: Function) => {
    const userId = req.session.userId;
    const targetEmployeeId = parseInt(req.params.id);
    
    if (!userId) {
      return res.status(401).json({ message: "Authentication required" });
    }
    
    // If accessing own data, allow
    if (userId === targetEmployeeId) {
      return next();
    }
    
    // Get all reportees for the current user
    const reportees = await storage.getAllReportees(userId);
    
    // Check if target employee is a reportee
    if (reportees.some(r => r.id === targetEmployeeId)) {
      return next();
    }
    
    return res.status(403).json({ message: "You don't have permission to access this employee's data" });
  };

  // Authentication routes - simplified for demo purposes
  app.post("/api/auth/login", async (req, res) => {
    const { email } = req.body;
    
    console.log("Login attempt for:", email);
    
    if (!email) {
      console.log("Login error: Email is required");
      return res.status(400).json({ message: "Email is required" });
    }
    
    // For demo purposes, we're using a very simple authentication system
    // In a real application, we would validate credentials properly
    const employee = await storage.getEmployeeByEmail(email);
    
    if (!employee) {
      console.log("Login error: Invalid email - user not found");
      return res.status(401).json({ message: "User not found with provided email" });
    }
    
    // Set the user ID in the session
    req.session.userId = employee.id;
    req.session.userEmail = employee.email;
    
    console.log("Login successful for:", email, "ID:", employee.id);
    
    // Get the full employee with manager info
    const employeeWithManager = await storage.getEmployeeWithManager(employee.id);
    
    // Response with the user info
    return res.json(employeeWithManager || employee);
  });
  
  app.get("/api/auth/me", async (req, res) => {
    const userId = req.session.userId;
    console.log("Auth check, session:", req.session.id, "User ID:", userId);
    
    if (!userId) {
      console.log("Auth check failed: No user ID in session");
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    try {
      // Get the employee with manager info
      const employee = await storage.getEmployeeWithManager(userId);
      
      if (!employee) {
        console.log("Auth check failed: Employee not found for ID:", userId);
        return res.status(404).json({ message: "Employee not found" });
      }
      
      console.log("Auth check successful for:", employee.name);
      return res.json(employee);
    } catch (error) {
      console.error("Error in /api/auth/me:", error);
      return res.status(500).json({ message: "Server error checking authentication" });
    }
  });
  
  app.post("/api/auth/logout", (req, res) => {
    console.log("Logout for session:", req.session.id);
    
    req.session.destroy((err) => {
      if (err) {
        console.error("Logout error:", err);
        return res.status(500).json({ success: false, message: "Logout failed" });
      }
      res.json({ success: true });
    });
  });

  // Employee routes
  app.get("/api/employees", requireAuth, async (req, res) => {
    const currentUserId = req.session.userId;
    
    if (!currentUserId) {
      return res.status(401).json({ message: "Authentication required" });
    }
    
    // Get the current user's reportees
    const reportees = await storage.getAllReportees(currentUserId);
    
    // Get the current user
    const currentUser = await storage.getEmployee(currentUserId);
    
    if (!currentUser) {
      return res.status(404).json({ message: "Current user not found" });
    }
    
    // Include the current user in the list
    const employees = [currentUser, ...reportees];
    
    // Enhance with manager info and direct reports count
    const enhancedEmployees = await Promise.all(
      employees.map(async (e) => await storage.getEmployeeWithManager(e.id))
    );
    
    return res.json(enhancedEmployees.filter(Boolean));
  });
  
  app.get("/api/employees/:id", requireAuth, canAccessEmployee, async (req, res) => {
    const id = parseInt(req.params.id);
    const employee = await storage.getEmployeeWithManager(id);
    
    if (!employee) {
      return res.status(404).json({ message: "Employee not found" });
    }
    
    return res.json(employee);
  });
  
  app.post("/api/employees", requireAuth, async (req, res) => {
    try {
      const validatedData = insertEmployeeSchema.parse(req.body);
      
      // Check if user has permission to create an employee with this manager
      if (validatedData.managerId) {
        const currentUserId = req.session.userId;
        
        if (validatedData.managerId !== currentUserId) {
          const reportees = await storage.getAllReportees(currentUserId!);
          
          if (!reportees.some(r => r.id === validatedData.managerId)) {
            return res.status(403).json({ 
              message: "You can only assign managers who are your direct or indirect reportees" 
            });
          }
        }
      }
      
      const employee = await storage.createEmployee(validatedData);
      return res.status(201).json(employee);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      throw error;
    }
  });
  
  app.put("/api/employees/:id", requireAuth, canAccessEmployee, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const currentUserId = req.session.userId;
      
      // Check if the user is updating manager to someone they don't manage
      if (req.body.managerId && req.body.managerId !== currentUserId) {
        const reportees = await storage.getAllReportees(currentUserId!);
        
        if (!reportees.some(r => r.id === req.body.managerId)) {
          return res.status(403).json({ 
            message: "You can only assign managers who are your direct or indirect reportees" 
          });
        }
      }
      
      const updatedEmployee = await storage.updateEmployee(id, req.body);
      
      if (!updatedEmployee) {
        return res.status(404).json({ message: "Employee not found" });
      }
      
      return res.json(updatedEmployee);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      throw error;
    }
  });
  
  app.delete("/api/employees/:id", requireAuth, canAccessEmployee, async (req, res) => {
    const id = parseInt(req.params.id);
    
    // Check if the employee has reportees
    const directReports = await storage.getDirectReports(id);
    
    if (directReports.length > 0) {
      return res.status(400).json({ 
        message: "Cannot delete an employee who has direct reports. Reassign reports first." 
      });
    }
    
    const result = await storage.deleteEmployee(id);
    
    if (!result) {
      return res.status(404).json({ message: "Employee not found" });
    }
    
    return res.json({ success: true });
  });

  // Feedback routes
  app.get("/api/feedback", requireAuth, async (req, res) => {
    const currentUserId = req.session.userId;
    
    if (!currentUserId) {
      return res.status(401).json({ message: "Authentication required" });
    }
    
    const feedback = await storage.getFeedbacksForManager(currentUserId);
    return res.json(feedback);
  });
  
  app.get("/api/feedback/:id", requireAuth, async (req, res) => {
    const id = parseInt(req.params.id);
    const feedback = await storage.getFeedback(id);
    
    if (!feedback) {
      return res.status(404).json({ message: "Feedback not found" });
    }
    
    // Check if user has access to this feedback
    const currentUserId = req.session.userId;
    const reportees = await storage.getAllReportees(currentUserId!);
    const reporteeIds = reportees.map(r => r.id);
    
    if (
      feedback.employeeId !== currentUserId && 
      !reporteeIds.includes(feedback.employeeId) &&
      feedback.giverId !== currentUserId
    ) {
      return res.status(403).json({ message: "You don't have permission to access this feedback" });
    }
    
    return res.json(feedback);
  });
  
  app.post("/api/feedback", requireAuth, async (req, res) => {
    try {
      const validatedData = insertFeedbackSchema.parse(req.body);
      const currentUserId = req.session.userId;
      
      // Set the current user as the feedback giver
      validatedData.giverId = currentUserId!;
      
      // Check if user can give feedback to this employee
      const targetEmployee = await storage.getEmployee(validatedData.employeeId);
      
      if (!targetEmployee) {
        return res.status(404).json({ message: "Employee not found" });
      }
      
      // If not self-feedback, check if target is a reportee
      if (validatedData.employeeId !== currentUserId) {
        const reportees = await storage.getAllReportees(currentUserId!);
        
        if (!reportees.some(r => r.id === validatedData.employeeId)) {
          return res.status(403).json({ 
            message: "You can only give feedback to your direct or indirect reportees" 
          });
        }
      }
      
      const feedback = await storage.createFeedback(validatedData);
      return res.status(201).json(feedback);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      throw error;
    }
  });
  
  app.put("/api/feedback/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const currentUserId = req.session.userId;
      
      // Check if the feedback exists and belongs to the current user
      const existingFeedback = await storage.getFeedback(id);
      
      if (!existingFeedback) {
        return res.status(404).json({ message: "Feedback not found" });
      }
      
      if (existingFeedback.giverId !== currentUserId) {
        return res.status(403).json({ message: "You can only update feedback you've given" });
      }
      
      const updatedFeedback = await storage.updateFeedback(id, req.body);
      
      if (!updatedFeedback) {
        return res.status(404).json({ message: "Feedback not found" });
      }
      
      return res.json(updatedFeedback);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      throw error;
    }
  });
  
  app.delete("/api/feedback/:id", requireAuth, async (req, res) => {
    const id = parseInt(req.params.id);
    const currentUserId = req.session.userId;
    
    // Check if the feedback exists and belongs to the current user
    const existingFeedback = await storage.getFeedback(id);
    
    if (!existingFeedback) {
      return res.status(404).json({ message: "Feedback not found" });
    }
    
    if (existingFeedback.giverId !== currentUserId) {
      return res.status(403).json({ message: "You can only delete feedback you've given" });
    }
    
    const result = await storage.deleteFeedback(id);
    
    if (!result) {
      return res.status(404).json({ message: "Feedback not found" });
    }
    
    return res.json({ success: true });
  });

  // Dashboard statistics
  app.get("/api/dashboard/stats", requireAuth, async (req, res) => {
    const currentUserId = req.session.userId;
    
    if (!currentUserId) {
      return res.status(401).json({ message: "Authentication required" });
    }
    
    // Get all reportees
    const reportees = await storage.getAllReportees(currentUserId);
    
    // Include current user in the count
    const teamSize = reportees.length + 1;
    
    // Get feedback for this month
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    
    const allFeedback = await storage.getFeedbacksForManager(currentUserId);
    
    const feedbackThisMonth = allFeedback.filter(f => 
      new Date(f.feedbackDate) >= startOfMonth
    );
    
    // Calculate pending feedback (simplified - in a real app this would be more complex)
    // For now, assume each employee should get at least one feedback per month
    const employeesWithFeedback = new Set(
      feedbackThisMonth.map(f => f.employeeId)
    );
    
    const pendingFeedback = reportees.filter(
      r => !employeesWithFeedback.has(r.id)
    ).length;
    
    // Calculate average score
    const totalRatings = allFeedback.reduce((sum, f) => sum + f.rating, 0);
    const avgScore = allFeedback.length > 0 
      ? (totalRatings / allFeedback.length).toFixed(1) 
      : "0.0";
    
    return res.json({
      teamMembers: teamSize,
      feedbackGiven: feedbackThisMonth.length,
      pendingFeedback,
      avgScore: `${avgScore}/5`
    });
  });
  
  // Recent feedback for dashboard
  app.get("/api/dashboard/recent-feedback", requireAuth, async (req, res) => {
    const currentUserId = req.session.userId;
    
    if (!currentUserId) {
      return res.status(401).json({ message: "Authentication required" });
    }
    
    const allFeedback = await storage.getFeedbacksForManager(currentUserId);
    
    // Sort by date descending and take first 3
    const recentFeedback = allFeedback
      .sort((a, b) => new Date(b.feedbackDate).getTime() - new Date(a.feedbackDate).getTime())
      .slice(0, 3);
    
    return res.json(recentFeedback);
  });

  // Import Excel data
  app.post("/api/import/employees", requireAuth, async (req, res) => {
    try {
      // Expect an array of employees from the frontend
      // The frontend will parse the Excel file and send the data
      const { employees } = req.body;
      
      if (!Array.isArray(employees) || employees.length === 0) {
        return res.status(400).json({ message: "Invalid or empty employees data" });
      }
      
      const validatedEmployees = [];
      
      for (const employee of employees) {
        try {
          const validData = insertEmployeeSchema.parse(employee);
          validatedEmployees.push(validData);
        } catch (error) {
          if (error instanceof z.ZodError) {
            return res.status(400).json({ 
              message: `Validation error for employee ${employee.name || 'unknown'}`, 
              errors: error.errors 
            });
          }
          throw error;
        }
      }
      
      const importedEmployees = await storage.importEmployees(validatedEmployees);
      
      return res.status(201).json({ 
        success: true, 
        count: importedEmployees.length,
        employees: importedEmployees
      });
    } catch (error) {
      console.error("Import error:", error);
      return res.status(500).json({ message: "Failed to import employees" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
