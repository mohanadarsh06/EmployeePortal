import 'express-session';

// Extend the session with our custom properties
declare module 'express-session' {
  interface SessionData {
    userId?: number;
    userEmail?: string;
  }
}