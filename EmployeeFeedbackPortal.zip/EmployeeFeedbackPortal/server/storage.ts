import { 
  Employee, 
  InsertEmployee, 
  Feedback, 
  InsertFeedback, 
  EmployeeWithManager,
  FeedbackWithNames
} from "@shared/schema";
import { db } from "./db";
import * as schema from "@shared/schema";
import { eq, inArray, count } from "drizzle-orm";

export interface IStorage {
  // Employee operations
  getEmployees(): Promise<Employee[]>;
  getEmployee(id: number): Promise<Employee | undefined>;
  getEmployeeByEmail(email: string): Promise<Employee | undefined>;
  getEmployeeByEmployeeId(employeeId: string): Promise<Employee | undefined>;
  createEmployee(employee: InsertEmployee): Promise<Employee>;
  updateEmployee(id: number, employee: Partial<Employee>): Promise<Employee | undefined>;
  deleteEmployee(id: number): Promise<boolean>;
  getEmployeeWithManager(id: number): Promise<EmployeeWithManager | undefined>;
  
  // Hierarchy operations
  getDirectReports(managerId: number): Promise<Employee[]>;
  getAllReportees(managerId: number): Promise<Employee[]>;
  getManagementChain(employeeId: number): Promise<Employee[]>;
  
  // Feedback operations
  getFeedbacks(): Promise<Feedback[]>;
  getFeedback(id: number): Promise<Feedback | undefined>;
  createFeedback(feedback: InsertFeedback): Promise<Feedback>;
  updateFeedback(id: number, feedback: Partial<Feedback>): Promise<Feedback | undefined>;
  deleteFeedback(id: number): Promise<boolean>;
  getFeedbacksByEmployee(employeeId: number): Promise<Feedback[]>;
  getFeedbacksByGiver(giverId: number): Promise<Feedback[]>;
  getFeedbacksForManager(managerId: number): Promise<FeedbackWithNames[]>;
  
  // Bulk operations for import
  importEmployees(employees: InsertEmployee[]): Promise<Employee[]>;
}

export class MemStorage implements IStorage {
  private employees: Map<number, Employee>;
  private feedbacks: Map<number, Feedback>;
  private employeeCurrentId: number;
  private feedbackCurrentId: number;

  constructor() {
    this.employees = new Map();
    this.feedbacks = new Map();
    this.employeeCurrentId = 1;
    this.feedbackCurrentId = 1;
    
    // Add initial sample data for demo
    this.createEmployee({
      name: "Sooraj Kumar",
      email: "sooraj@example.com",
      employeeId: "EMP001",
      position: "Senior Manager",
      department: "Engineering",
      managerId: null,
      joinDate: new Date("2020-01-02"),
      isActive: true
    });
    
    const anuja = this.createEmployee({
      name: "Anuja S",
      email: "anuja@example.com",
      employeeId: "EMP002",
      position: "Manager",
      department: "Engineering",
      managerId: 1,
      joinDate: new Date("2020-02-03"),
      isActive: true
    });
    
    this.createEmployee({
      name: "Adarsh R",
      email: "adarsh@example.com",
      employeeId: "EMP003",
      position: "Developer",
      department: "Engineering",
      managerId: 2,
      joinDate: new Date("2021-03-04"),
      isActive: true
    });
    
    this.createEmployee({
      name: "Vinod K",
      email: "vinod@example.com",
      employeeId: "EMP004",
      position: "QA Engineer",
      department: "QA",
      managerId: 1,
      joinDate: new Date("2021-06-05"),
      isActive: true
    });
    
    this.createEmployee({
      name: "Asha M",
      email: "asha@example.com",
      employeeId: "EMP005",
      position: "Designer",
      department: "Design",
      managerId: 1,
      joinDate: new Date("2022-01-06"),
      isActive: true
    });
    
    // Add some sample feedback
    this.createFeedback({
      employeeId: 3, // Adarsh
      giverId: 2,    // Anuja (Manager)
      rating: 4,
      feedbackDate: new Date("2023-10-15"),
      comment: "Adarsh has shown excellent problem-solving skills and consistently delivers high-quality code. He's been instrumental in our recent project delivery.",
      areasForImprovement: "Should work on better documentation and knowledge sharing with the team.",
      categories: "Technical Skills, Quality"
    });
    
    this.createFeedback({
      employeeId: 3, // Adarsh
      giverId: 2,    // Anuja (Manager)
      rating: 3,
      feedbackDate: new Date("2023-07-20"),
      comment: "Adarsh's performance has been satisfactory this quarter. He completes assigned tasks on time.",
      areasForImprovement: "Needs to improve communication with team members and take more initiative.",
      categories: "Communication, Initiative"
    });
    
    this.createFeedback({
      employeeId: 2, // Anuja
      giverId: 1,    // Sooraj (Manager)
      rating: 5,
      feedbackDate: new Date("2023-09-10"),
      comment: "Anuja is an exceptional manager who consistently guides her team to excellent results. Her leadership during the challenging XYZ project was outstanding.",
      areasForImprovement: "Could delegate more tasks to develop team members' skills.",
      categories: "Leadership, Management"
    });
  }

  // Employee operations
  async getEmployees(): Promise<Employee[]> {
    return Array.from(this.employees.values());
  }

  async getEmployee(id: number): Promise<Employee | undefined> {
    return this.employees.get(id);
  }

  async getEmployeeByEmail(email: string): Promise<Employee | undefined> {
    return Array.from(this.employees.values()).find(
      (employee) => employee.email === email
    );
  }

  async getEmployeeByEmployeeId(employeeId: string): Promise<Employee | undefined> {
    return Array.from(this.employees.values()).find(
      (employee) => employee.employeeId === employeeId
    );
  }

  async createEmployee(employee: InsertEmployee): Promise<Employee> {
    const id = this.employeeCurrentId++;
    const newEmployee: Employee = { ...employee, id };
    this.employees.set(id, newEmployee);
    return newEmployee;
  }

  async updateEmployee(id: number, employeeUpdate: Partial<Employee>): Promise<Employee | undefined> {
    const employee = this.employees.get(id);
    if (!employee) return undefined;
    
    const updatedEmployee = { ...employee, ...employeeUpdate };
    this.employees.set(id, updatedEmployee);
    return updatedEmployee;
  }

  async deleteEmployee(id: number): Promise<boolean> {
    return this.employees.delete(id);
  }

  async getEmployeeWithManager(id: number): Promise<EmployeeWithManager | undefined> {
    const employee = this.employees.get(id);
    if (!employee) return undefined;

    const manager = employee.managerId ? this.employees.get(employee.managerId) : undefined;
    
    // Count direct reports
    const directReports = Array.from(this.employees.values()).filter(
      (emp) => emp.managerId === id
    ).length;
    
    return {
      ...employee,
      manager,
      directReports
    };
  }

  // Hierarchy operations
  async getDirectReports(managerId: number): Promise<Employee[]> {
    return Array.from(this.employees.values()).filter(
      (employee) => employee.managerId === managerId
    );
  }

  async getAllReportees(managerId: number): Promise<Employee[]> {
    const reportees: Employee[] = [];
    
    // Get direct reports
    const directReports = await this.getDirectReports(managerId);
    reportees.push(...directReports);
    
    // Recursively get indirect reports
    for (const report of directReports) {
      const indirectReports = await this.getAllReportees(report.id);
      reportees.push(...indirectReports);
    }
    
    return reportees;
  }

  async getManagementChain(employeeId: number): Promise<Employee[]> {
    const chain: Employee[] = [];
    let currentEmployee = this.employees.get(employeeId);
    
    while (currentEmployee && currentEmployee.managerId) {
      const manager = this.employees.get(currentEmployee.managerId);
      if (manager) {
        chain.push(manager);
        currentEmployee = manager;
      } else {
        break;
      }
    }
    
    return chain;
  }

  // Feedback operations
  async getFeedbacks(): Promise<Feedback[]> {
    return Array.from(this.feedbacks.values());
  }

  async getFeedback(id: number): Promise<Feedback | undefined> {
    return this.feedbacks.get(id);
  }

  async createFeedback(feedback: InsertFeedback): Promise<Feedback> {
    const id = this.feedbackCurrentId++;
    const newFeedback: Feedback = { ...feedback, id };
    this.feedbacks.set(id, newFeedback);
    return newFeedback;
  }

  async updateFeedback(id: number, feedbackUpdate: Partial<Feedback>): Promise<Feedback | undefined> {
    const feedback = this.feedbacks.get(id);
    if (!feedback) return undefined;
    
    const updatedFeedback = { ...feedback, ...feedbackUpdate };
    this.feedbacks.set(id, updatedFeedback);
    return updatedFeedback;
  }

  async deleteFeedback(id: number): Promise<boolean> {
    return this.feedbacks.delete(id);
  }

  async getFeedbacksByEmployee(employeeId: number): Promise<Feedback[]> {
    return Array.from(this.feedbacks.values()).filter(
      (feedback) => feedback.employeeId === employeeId
    );
  }

  async getFeedbacksByGiver(giverId: number): Promise<Feedback[]> {
    return Array.from(this.feedbacks.values()).filter(
      (feedback) => feedback.giverId === giverId
    );
  }

  async getFeedbacksForManager(managerId: number): Promise<FeedbackWithNames[]> {
    // Get all reportees (direct and indirect)
    const reportees = await this.getAllReportees(managerId);
    const reporteeIds = reportees.map(r => r.id);
    
    // Include the manager's own feedback as well
    reporteeIds.push(managerId);
    
    // Get all feedback for these employees
    const feedbacks = Array.from(this.feedbacks.values()).filter(
      (feedback) => reporteeIds.includes(feedback.employeeId)
    );
    
    // Enhance feedback with names
    return feedbacks.map(feedback => {
      const employee = this.employees.get(feedback.employeeId);
      const giver = this.employees.get(feedback.giverId);
      
      return {
        ...feedback,
        employeeName: employee?.name,
        giverName: giver?.name,
        employeeInitials: employee?.name
          .split(' ')
          .map(n => n[0])
          .join('')
      };
    });
  }

  // Bulk operations for import
  async importEmployees(employees: InsertEmployee[]): Promise<Employee[]> {
    const imported: Employee[] = [];
    
    for (const employee of employees) {
      const newEmployee = await this.createEmployee(employee);
      imported.push(newEmployee);
    }
    
    return imported;
  }
}

// Create a DatabaseStorage class
export class DatabaseStorage implements IStorage {
  async getEmployees(): Promise<Employee[]> {
    const employees = await db.select().from(schema.employees);
    return employees;
  }
  
  async getEmployee(id: number): Promise<Employee | undefined> {
    const [employee] = await db.select().from(schema.employees).where(eq(schema.employees.id, id));
    return employee || undefined;
  }
  
  async getEmployeeByEmail(email: string): Promise<Employee | undefined> {
    const [employee] = await db.select().from(schema.employees).where(eq(schema.employees.email, email));
    return employee || undefined;
  }
  
  async getEmployeeByEmployeeId(employeeId: string): Promise<Employee | undefined> {
    const [employee] = await db.select().from(schema.employees).where(eq(schema.employees.employeeId, employeeId));
    return employee || undefined;
  }
  
  async createEmployee(employee: InsertEmployee): Promise<Employee> {
    const [newEmployee] = await db.insert(schema.employees).values(employee).returning();
    return newEmployee;
  }
  
  async updateEmployee(id: number, employeeUpdate: Partial<Employee>): Promise<Employee | undefined> {
    const [updatedEmployee] = await db
      .update(schema.employees)
      .set(employeeUpdate)
      .where(eq(schema.employees.id, id))
      .returning();
    return updatedEmployee || undefined;
  }
  
  async deleteEmployee(id: number): Promise<boolean> {
    try {
      await db.delete(schema.employees).where(eq(schema.employees.id, id));
      return true;
    } catch (error) {
      console.error("Error deleting employee:", error);
      return false;
    }
  }
  
  async getEmployeeWithManager(id: number): Promise<EmployeeWithManager | undefined> {
    const [employee] = await db.select().from(schema.employees).where(eq(schema.employees.id, id));
    
    if (!employee) {
      return undefined;
    }
    
    let manager: Employee | undefined;
    if (employee.managerId) {
      const [managerData] = await db
        .select()
        .from(schema.employees)
        .where(eq(schema.employees.id, employee.managerId));
      manager = managerData;
    }
    
    // Count direct reports
    const directReports = await db
      .select({ count: count() })
      .from(schema.employees)
      .where(eq(schema.employees.managerId, id));
    
    return {
      ...employee,
      manager,
      directReports: directReports[0]?.count || 0
    };
  }
  
  async getDirectReports(managerId: number): Promise<Employee[]> {
    const directReports = await db
      .select()
      .from(schema.employees)
      .where(eq(schema.employees.managerId, managerId));
    return directReports;
  }
  
  async getAllReportees(managerId: number): Promise<Employee[]> {
    // First, get direct reports
    const directReports = await this.getDirectReports(managerId);
    let allReportees = [...directReports];
    
    // For each direct report, get their reportees recursively
    for (const report of directReports) {
      const indirectReports = await this.getAllReportees(report.id);
      allReportees = [...allReportees, ...indirectReports];
    }
    
    return allReportees;
  }
  
  async getManagementChain(employeeId: number): Promise<Employee[]> {
    const chain: Employee[] = [];
    let currentId = employeeId;
    
    // To prevent infinite loops
    const visited = new Set<number>();
    
    while (currentId && !visited.has(currentId)) {
      visited.add(currentId);
      
      const [employee] = await db
        .select()
        .from(schema.employees)
        .where(eq(schema.employees.id, currentId));
      
      if (!employee) {
        break;
      }
      
      if (employee.managerId && employee.managerId !== currentId) {
        chain.push(employee);
        currentId = employee.managerId;
      } else {
        // If employee has no manager or is their own manager, stop
        if (!chain.includes(employee)) {
          chain.push(employee);
        }
        break;
      }
    }
    
    return chain;
  }
  
  async getFeedbacks(): Promise<Feedback[]> {
    const feedbacks = await db.select().from(schema.feedbacks);
    return feedbacks;
  }
  
  async getFeedback(id: number): Promise<Feedback | undefined> {
    const [feedback] = await db
      .select()
      .from(schema.feedbacks)
      .where(eq(schema.feedbacks.id, id));
    return feedback || undefined;
  }
  
  async createFeedback(feedback: InsertFeedback): Promise<Feedback> {
    const [newFeedback] = await db
      .insert(schema.feedbacks)
      .values(feedback)
      .returning();
    return newFeedback;
  }
  
  async updateFeedback(id: number, feedbackUpdate: Partial<Feedback>): Promise<Feedback | undefined> {
    const [updatedFeedback] = await db
      .update(schema.feedbacks)
      .set(feedbackUpdate)
      .where(eq(schema.feedbacks.id, id))
      .returning();
    return updatedFeedback || undefined;
  }
  
  async deleteFeedback(id: number): Promise<boolean> {
    try {
      await db.delete(schema.feedbacks).where(eq(schema.feedbacks.id, id));
      return true;
    } catch (error) {
      console.error("Error deleting feedback:", error);
      return false;
    }
  }
  
  async getFeedbacksByEmployee(employeeId: number): Promise<Feedback[]> {
    const feedbacks = await db
      .select()
      .from(schema.feedbacks)
      .where(eq(schema.feedbacks.employeeId, employeeId));
    return feedbacks;
  }
  
  async getFeedbacksByGiver(giverId: number): Promise<Feedback[]> {
    const feedbacks = await db
      .select()
      .from(schema.feedbacks)
      .where(eq(schema.feedbacks.giverId, giverId));
    return feedbacks;
  }
  
  async getFeedbacksForManager(managerId: number): Promise<FeedbackWithNames[]> {
    // Get all employees this manager is responsible for (including indirect)
    const reportees = await this.getAllReportees(managerId);
    const reporteeIds = reportees.map(r => r.id);
    
    // Include the manager's own feedback
    const allIds = [managerId, ...reporteeIds];
    
    // Get feedbacks for all these employees
    const feedbacks = await db
      .select()
      .from(schema.feedbacks)
      .where(inArray(schema.feedbacks.employeeId, allIds));
    
    // Create a map of employee IDs to names for quick lookup
    const employeeMap = new Map<number, string>();
    
    // Get names for all employees and givers in one query
    const allEmployeeIds = new Set([
      ...feedbacks.map(f => f.employeeId),
      ...feedbacks.map(f => f.giverId)
    ]);
    
    const employees = await db
      .select()
      .from(schema.employees)
      .where(inArray(schema.employees.id, Array.from(allEmployeeIds)));
    
    for (const emp of employees) {
      employeeMap.set(emp.id, emp.name);
    }
    
    // Enhance feedbacks with names
    return feedbacks.map(feedback => {
      const employeeName = employeeMap.get(feedback.employeeId);
      const giverName = employeeMap.get(feedback.giverId);
      
      return {
        ...feedback,
        employeeName: employeeName || 'Unknown',
        giverName: giverName || 'Unknown',
        employeeInitials: employeeName ? employeeName.split(' ').map(n => n[0]).join('') : 'UN'
      };
    });
  }
  
  async importEmployees(employees: InsertEmployee[]): Promise<Employee[]> {
    if (employees.length === 0) {
      return [];
    }
    
    const insertedEmployees = await db
      .insert(schema.employees)
      .values(employees)
      .returning();
    
    return insertedEmployees;
  }
}

// Use DatabaseStorage instead of MemStorage
export const storage = new DatabaseStorage();
