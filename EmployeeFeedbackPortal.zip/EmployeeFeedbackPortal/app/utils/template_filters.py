def register_filters(app):
    """Register custom template filters."""
    
    @app.template_filter('initial')
    def get_initials(name):
        """Get the initials from a name."""
        if not name:
            return ''
        
        parts = name.split()
        initials = ''.join([part[0].upper() for part in parts if part])
        return initials