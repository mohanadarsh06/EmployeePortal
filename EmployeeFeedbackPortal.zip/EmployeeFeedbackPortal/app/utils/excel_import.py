"""Utility functions for importing data from Excel files."""
import os
import openpyxl
from datetime import datetime
from app.models import Employee, db
from werkzeug.security import generate_password_hash
import logging

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def parse_excel_date(date_value):
    """Parse Excel date to Python datetime."""
    if isinstance(date_value, datetime):
        return date_value
    try:
        # Try parsing as string in common formats
        for fmt in ["%Y-%m-%d", "%d/%m/%Y", "%m/%d/%Y", "%d-%m-%Y", "%m-%d-%Y"]:
            try:
                return datetime.strptime(str(date_value), fmt)
            except (ValueError, TypeError):
                continue
        # If all attempts fail, return current date
        return datetime.now()
    except Exception:
        return datetime.now()

def map_excel_headers(headers):
    """Map Excel headers to database fields."""
    header_mapping = {
        'name': ['name', 'employee name', 'full name', 'full_name'],
        'email': ['email', 'email address', 'mail', 'emailid'],
        'employee_id': ['employee id', 'id', 'employee no', 'employee number', 'emp id', 'system_id'],
        'position': ['position', 'title', 'job title', 'role', 'role ', 'designation'],
        'department': ['department', 'dept', 'team', 'division'],
        'manager_id': ['manager id', 'manager id', 'reports to', 'supervisor'],
        'manager_name': ['manager name', 'manager_name', 'reports to name', 'supervisor name'],
        'join_date': ['join date', 'joining date', 'date of joining', 'hire date', 'doj', 'doj allianz'],
        'is_active': ['active', 'is active', 'status', 'employee_status']
    }
    
    result = {}
    for field, aliases in header_mapping.items():
        for idx, header in enumerate(headers):
            if header and str(header).lower().strip() in aliases:
                result[field] = idx
                break
    
    return result

def find_manager_by_name(manager_name):
    """Find a manager by name."""
    if not manager_name:
        return None
    
    # Try exact match first
    manager = Employee.query.filter(Employee.name == manager_name).first()
    if manager:
        return manager
    
    # Try case-insensitive match
    manager = Employee.query.filter(db.func.lower(Employee.name) == manager_name.lower()).first()
    return manager

def import_employees_from_excel(file_path):
    """Import employees from Excel file."""
    if not os.path.exists(file_path):
        return {"success": False, "error": f"File not found: {file_path}"}
    
    try:
        workbook = openpyxl.load_workbook(file_path)
        
        # Try to find the most appropriate sheet
        target_sheet = None
        best_sheet_name = None
        for sheet_name in workbook.sheetnames:
            if sheet_name.lower() in ['full list', 'employees', 'staff', 'personnel']:
                target_sheet = workbook[sheet_name]
                best_sheet_name = sheet_name
                break
        
        # If no appropriate sheet found, use the active sheet
        if not target_sheet:
            target_sheet = workbook.active
            best_sheet_name = target_sheet.title
        
        logger.info(f"Importing from sheet: {best_sheet_name}")
        
        rows = list(target_sheet.rows)
        if not rows:
            return {"success": False, "error": "Empty Excel sheet"}
        
        headers = [cell.value for cell in rows[0]]
        header_mapping = map_excel_headers(headers)
        
        logger.info(f"Found headers: {headers}")
        logger.info(f"Mapped headers: {header_mapping}")
        
        # More lenient validation - we need at least name and a way to identify employees
        required_minimum = ['name']
        missing_minimum = [field for field in required_minimum if field not in header_mapping]
        
        if missing_minimum:
            return {
                "success": False, 
                "error": f"Missing required column: name"
            }
        
        results = {
            "total": len(rows) - 1,
            "created": 0,
            "errors": []
        }
        
        # First pass: Create all employees
        employees_to_update = []
        
        for i, row in enumerate(rows[1:], 1):
            try:
                # Skip empty rows
                if not any(cell.value for cell in row):
                    continue
                
                data = {
                    'name': '',
                    'password_hash': generate_password_hash('password'),  # Default password
                    'is_active': True  # Default to active
                }
                
                # Extract values from row using our header mapping
                for field, idx in header_mapping.items():
                    value = row[idx].value
                    
                    if not value:
                        continue
                        
                    if field == 'join_date':
                        data[field] = parse_excel_date(value)
                    elif field == 'is_active':
                        # Handle various representations of boolean values
                        if isinstance(value, bool):
                            data[field] = value
                        elif isinstance(value, str):
                            data[field] = value.lower() in ['true', 'yes', 'active', '1']
                        elif isinstance(value, (int, float)):
                            data[field] = bool(value)
                        else:
                            data[field] = True
                    elif field in ['manager_id', 'manager_name']:
                        # Handle separately
                        pass
                    else:
                        data[field] = str(value)
                
                # Skip if no name (likely header or empty row)
                if not data.get('name'):
                    continue
                
                # Generate email if not provided
                if 'email' not in data or not data['email']:
                    data['email'] = f"{data['name'].lower().replace(' ', '.')}@example.com"
                
                # Generate employee_id if not provided
                if 'employee_id' not in data or not data['employee_id']:
                    data['employee_id'] = f"EMP{i:04d}"
                
                # Set default position if not provided
                if 'position' not in data or not data['position']:
                    data['position'] = "Employee"
                    
                # Set default department if not provided
                if 'department' not in data or not data['department']:
                    data['department'] = "General"
                
                # Check if email already exists
                existing = Employee.query.filter_by(email=data['email']).first()
                if existing:
                    results["errors"].append({
                        "row": i + 1,
                        "error": f"Email already exists: {data['email']}"
                    })
                    continue
                
                # Check if employee_id already exists
                existing = Employee.query.filter_by(employee_id=data['employee_id']).first()
                if existing:
                    results["errors"].append({
                        "row": i + 1,
                        "error": f"Employee ID already exists: {data['employee_id']}"
                    })
                    continue
                
                # Save manager information for second pass
                manager_info = None
                if 'manager_id' in header_mapping and row[header_mapping['manager_id']].value:
                    manager_info = {
                        'type': 'id',
                        'value': row[header_mapping['manager_id']].value
                    }
                elif 'manager_name' in header_mapping and row[header_mapping['manager_name']].value:
                    manager_info = {
                        'type': 'name',
                        'value': row[header_mapping['manager_name']].value
                    }
                
                # Create employee record
                employee = Employee(
                    name=data['name'],
                    email=data['email'],
                    employee_id=data['employee_id'],
                    position=data['position'],
                    department=data['department'],
                    join_date=data.get('join_date', datetime.now()),
                    is_active=data.get('is_active', True),
                    password_hash=data['password_hash']
                )
                
                db.session.add(employee)
                db.session.flush()  # To get the ID
                
                if manager_info:
                    employees_to_update.append({
                        'employee': employee,
                        'manager_info': manager_info
                    })
                
                results["created"] += 1
                
            except Exception as e:
                results["errors"].append({
                    "row": i + 1,
                    "error": str(e)
                })
                logger.error(f"Error in row {i+1}: {str(e)}")
        
        # Second pass: Update manager relationships
        for item in employees_to_update:
            employee = item['employee']
            manager_info = item['manager_info']
            
            try:
                if manager_info['type'] == 'id':
                    manager_id = manager_info['value']
                    if isinstance(manager_id, str) and manager_id.isdigit():
                        manager_id = int(manager_id)
                    
                    manager = Employee.query.get(manager_id)
                    if manager:
                        employee.manager_id = manager.id
                    else:
                        logger.warning(f"Manager with ID {manager_id} not found for {employee.name}")
                
                elif manager_info['type'] == 'name':
                    manager_name = manager_info['value']
                    manager = find_manager_by_name(manager_name)
                    
                    if manager:
                        employee.manager_id = manager.id
                    else:
                        logger.warning(f"Manager with name '{manager_name}' not found for {employee.name}")
            
            except Exception as e:
                results["errors"].append({
                    "row": "unknown",
                    "error": f"Error setting manager for {employee.name}: {str(e)}"
                })
                logger.error(f"Error setting manager for {employee.name}: {str(e)}")
        
        # Commit changes if any employees were created
        if results["created"] > 0:
            db.session.commit()
            logger.info(f"Successfully imported {results['created']} employees from Excel")
        
        results["success"] = results["created"] > 0
        return results
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Import failed: {str(e)}")
        return {"success": False, "error": str(e)}