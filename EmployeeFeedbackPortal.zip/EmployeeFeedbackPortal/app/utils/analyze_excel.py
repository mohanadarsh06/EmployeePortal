"""
Script to analyze the structure of an Excel file to understand its contents and schema.
"""
import os
import sys
import openpyxl

def analyze_excel(file_path):
    """Analyze an Excel file to understand its structure."""
    if not os.path.exists(file_path):
        print(f"Error: File {file_path} does not exist.")
        return
    
    try:
        workbook = openpyxl.load_workbook(file_path)
        
        print(f"\nAnalyzing Excel file: {file_path}")
        print(f"Number of sheets: {len(workbook.sheetnames)}")
        print(f"Sheet names: {', '.join(workbook.sheetnames)}")
        
        for sheet_name in workbook.sheetnames:
            sheet = workbook[sheet_name]
            print(f"\nSheet: {sheet_name}")
            print(f"Dimensions: {sheet.dimensions}")
            
            # Get headers (assuming first row contains headers)
            headers = []
            for cell in sheet[1]:
                headers.append(cell.value)
            
            print(f"Headers: {headers}")
            
            # Display some sample data (first 5 rows)
            print("\nSample data (first 5 rows):")
            for row_idx, row in enumerate(sheet.iter_rows(min_row=2, max_row=6), 2):
                row_data = []
                for cell in row:
                    row_data.append(str(cell.value) if cell.value is not None else "None")
                print(f"Row {row_idx}: {row_data}")
            
            # Count non-empty rows
            row_count = 0
            for row in sheet.iter_rows(min_row=2):
                if any(cell.value for cell in row):
                    row_count += 1
            
            print(f"\nTotal data rows: {row_count}")
            
    except Exception as e:
        print(f"Error analyzing Excel file: {e}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python analyze_excel.py <excel_file_path>")
        sys.exit(1)
    
    analyze_excel(sys.argv[1])