from app.models import db, Employee, Feedback
from werkzeug.security import generate_password_hash
from datetime import datetime, timedelta
import random
import os
from .excel_import import import_employees_from_excel

def import_from_excel_if_provided():
    """Import employees from Excel file if provided in EXCEL_IMPORT_PATH."""
    excel_path = os.environ.get('EXCEL_IMPORT_PATH')
    if not excel_path or not os.path.exists(excel_path):
        return False
    
    print(f"Found Excel file at {excel_path}, importing employees...")
    try:
        result = import_employees_from_excel(excel_path)
        if result['success']:
            print(f"Successfully imported {result['created']} employees from Excel")
            if result['errors']:
                print(f"Encountered {len(result['errors'])} errors during import:")
                for error in result['errors']:
                    print(f"  Row {error['row']}: {error['error']}")
            return True
        else:
            print(f"Failed to import employees from Excel: {result.get('error', 'Unknown error')}")
            return False
    except Exception as e:
        print(f"Error importing from Excel: {e}")
        return False

def seed_database():
    """Seed the database with initial data if none exists."""
    # Check if any employees exist
    if Employee.query.count() > 0:
        print("Database already has data, skipping seed")
        return False
    
    # Try importing from Excel first
    if import_from_excel_if_provided():
        return True
    
    print("Seeding database with initial data...")
    
    try:
        # Create top-level manager
        director = Employee(
            name='Sooraj Kumar',
            email='sooraj@example.com',
            password_hash=generate_password_hash('password'),
            employee_id='EMP001',
            position='Director',
            department='Executive',
            join_date=datetime.now().date() - timedelta(days=365),
            is_active=True
        )
        db.session.add(director)
        db.session.flush()  # To get the ID
        
        # Create mid-level managers
        manager1 = Employee(
            name='Anuja S',
            email='anuja@example.com',
            password_hash=generate_password_hash('password'),
            employee_id='EMP002',
            position='Manager',
            department='Engineering',
            manager_id=director.id,
            join_date=datetime.now().date() - timedelta(days=300),
            is_active=True
        )
        db.session.add(manager1)
        db.session.flush()
        
        # Create employees
        employee1 = Employee(
            name='Adarsh R',
            email='adarsh@example.com',
            password_hash=generate_password_hash('password'),
            employee_id='EMP003',
            position='Developer',
            department='Engineering',
            manager_id=manager1.id,
            join_date=datetime.now().date() - timedelta(days=200),
            is_active=True
        )
        db.session.add(employee1)
        
        employee2 = Employee(
            name='Vinod K',
            email='vinod@example.com',
            password_hash=generate_password_hash('password'),
            employee_id='EMP004',
            position='QA Engineer',
            department='Quality',
            manager_id=director.id,
            join_date=datetime.now().date() - timedelta(days=180),
            is_active=True
        )
        db.session.add(employee2)
        
        employee3 = Employee(
            name='Asha M',
            email='asha@example.com',
            password_hash=generate_password_hash('password'),
            employee_id='EMP005',
            position='Designer',
            department='Design',
            manager_id=director.id,
            join_date=datetime.now().date() - timedelta(days=150),
            is_active=True
        )
        db.session.add(employee3)
        
        # Add some sample feedback
        # Manager giving feedback to employees
        feedbacks = [
            Feedback(
                employee_id=employee1.id,
                giver_id=manager1.id,
                rating=4,
                comment="Great work on the latest project. Your attention to detail is commendable.",
                feedback_date=datetime.now().date() - timedelta(days=30),
                areas_for_improvement="Could improve communication with other team members.",
                categories="Technical Skills, Communication"
            ),
            Feedback(
                employee_id=employee1.id,
                giver_id=manager1.id,
                rating=3,
                comment="Good progress on learning new technologies.",
                feedback_date=datetime.now().date() - timedelta(days=60),
                areas_for_improvement="Need to focus more on code quality and tests.",
                categories="Technical Skills, Learning"
            ),
            Feedback(
                employee_id=employee2.id,
                giver_id=director.id,
                rating=5,
                comment="Excellent work identifying and fixing critical bugs.",
                feedback_date=datetime.now().date() - timedelta(days=15),
                areas_for_improvement="Consider documentation improvements.",
                categories="Quality Assurance, Documentation"
            ),
            Feedback(
                employee_id=employee3.id,
                giver_id=director.id,
                rating=4,
                comment="Your designs have received positive feedback from clients.",
                feedback_date=datetime.now().date() - timedelta(days=45),
                areas_for_improvement="Work on meeting tight deadlines more consistently.",
                categories="Design, Creativity"
            )
        ]
        
        for feedback in feedbacks:
            db.session.add(feedback)
        
        db.session.commit()
        print("Database seeded successfully")
        return True
        
    except Exception as e:
        db.session.rollback()
        print(f"Error seeding database: {e}")
        return False