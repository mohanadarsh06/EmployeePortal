from flask import Blueprint, render_template, redirect, url_for, request, flash, jsonify
from flask_login import login_user, logout_user, current_user, login_required
from app.models import Employee, db
from werkzeug.security import generate_password_hash, check_password_hash
import json

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    """Handle user login."""
    if current_user.is_authenticated:
        return redirect(url_for('dashboard.index'))
    
    if request.method == 'POST':
        # Check if it's a direct login (for demo purposes)
        if request.is_json:
            data = request.get_json()
            email = data.get('email')
            
            # Skip password check for demo direct login
            user = Employee.query.filter_by(email=email).first()
            if user:
                login_user(user)
                return jsonify({'success': True, 'redirect': url_for('dashboard.index')})
            else:
                return jsonify({'success': False, 'message': 'User not found'}), 404
        
        # Normal form-based login
        email = request.form.get('email')
        password = request.form.get('password')
        
        user = Employee.query.filter_by(email=email).first()
        
        if not user or not user.check_password(password):
            flash('Please check your login details and try again.', 'danger')
            return redirect(url_for('auth.login'))
        
        login_user(user)
        return redirect(url_for('dashboard.index'))
    
    return render_template('auth/login.html')

@auth_bp.route('/logout')
@login_required
def logout():
    """Handle user logout."""
    logout_user()
    flash('You have been logged out successfully.', 'success')
    return redirect(url_for('auth.login'))

@auth_bp.route('/api/user')
@login_required
def get_current_user():
    """Return current user details for API requests."""
    return jsonify(current_user.to_dict())

# This function is for development/demo purposes only
@auth_bp.route('/api/create-demo-users', methods=['POST'])
def create_demo_users():
    """Create demo users for the application if they don't exist."""
    # Check if any employee exists
    if Employee.query.count() > 0:
        return jsonify({'success': False, 'message': 'Demo users already exist'}), 400
    
    try:
        # Create top-level manager
        director = Employee(
            name='Sooraj Kumar',
            email='sooraj@example.com',
            password_hash=generate_password_hash('password'),
            employee_id='EMP001',
            position='Director',
            department='Executive',
            is_active=True
        )
        db.session.add(director)
        db.session.flush()  # To get the ID
        
        # Create mid-level managers
        manager1 = Employee(
            name='Anuja S',
            email='anuja@example.com',
            password_hash=generate_password_hash('password'),
            employee_id='EMP002',
            position='Manager',
            department='Engineering',
            manager_id=director.id,
            is_active=True
        )
        db.session.add(manager1)
        db.session.flush()
        
        # Create employees
        employee1 = Employee(
            name='Adarsh R',
            email='adarsh@example.com',
            password_hash=generate_password_hash('password'),
            employee_id='EMP003',
            position='Developer',
            department='Engineering',
            manager_id=manager1.id,
            is_active=True
        )
        db.session.add(employee1)
        
        db.session.commit()
        return jsonify({'success': True, 'message': 'Demo users created successfully'})
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'message': str(e)}), 500