from flask import Blueprint, render_template, redirect, url_for, request, flash, jsonify
from flask_login import login_required, current_user
from app.models import Employee, db
from werkzeug.security import generate_password_hash
from datetime import datetime
import json
import re

employee_bp = Blueprint('employees', __name__, url_prefix='/employees')

def can_access_employee(employee_id):
    """Check if the current user can access the employee."""
    # Get the employee
    employee = Employee.query.get_or_404(employee_id)
    
    # Self access
    if employee.id == current_user.id:
        return True
    
    # Direct manager access
    if employee.manager_id == current_user.id:
        return True
    
    # Check if employee is in the reportee hierarchy
    reportees = current_user.get_all_reportees()
    return employee in reportees

@employee_bp.route('/')
@login_required
def index():
    """Render the employees page."""
    return render_template('employees/index.html')

@employee_bp.route('/api/employees')
@login_required
def get_employees():
    """Get all employees that the current user has access to."""
    # Get all reportees plus the current user
    reportees = current_user.get_all_reportees()
    reportees.append(current_user)
    
    # Convert to dictionary format with manager info
    result = []
    for employee in reportees:
        # Get manager info
        manager = None
        if employee.manager_id:
            mgr = Employee.query.get(employee.manager_id)
            if mgr:
                manager = mgr.to_dict()
        
        # Get number of direct reports
        direct_reports = Employee.query.filter_by(manager_id=employee.id).count()
        
        employee_dict = employee.to_dict()
        employee_dict['manager'] = manager
        employee_dict['direct_reports'] = direct_reports
        
        result.append(employee_dict)
    
    return jsonify(result)

@employee_bp.route('/api/employees/<int:employee_id>')
@login_required
def get_employee(employee_id):
    """Get a specific employee."""
    if not can_access_employee(employee_id):
        return jsonify({'error': 'Unauthorized access'}), 403
    
    employee = Employee.query.get_or_404(employee_id)
    
    # Get manager info
    manager = None
    if employee.manager_id:
        mgr = Employee.query.get(employee.manager_id)
        if mgr:
            manager = mgr.to_dict()
    
    # Get number of direct reports
    direct_reports = Employee.query.filter_by(manager_id=employee.id).count()
    
    employee_dict = employee.to_dict()
    employee_dict['manager'] = manager
    employee_dict['direct_reports'] = direct_reports
    
    return jsonify(employee_dict)

@employee_bp.route('/api/employees', methods=['POST'])
@login_required
def create_employee():
    """Create a new employee."""
    data = request.get_json()
    
    # Basic validation
    required_fields = ['name', 'email', 'employee_id', 'position', 'department']
    for field in required_fields:
        if field not in data or not data[field]:
            return jsonify({'error': f'Missing required field: {field}'}), 400
    
    # Email validation
    if not re.match(r"[^@]+@[^@]+\.[^@]+", data['email']):
        return jsonify({'error': 'Invalid email format'}), 400
    
    # Check if email exists
    existing_email = Employee.query.filter_by(email=data['email']).first()
    if existing_email:
        return jsonify({'error': 'Email already exists'}), 400
    
    # Check if employee_id exists
    existing_id = Employee.query.filter_by(employee_id=data['employee_id']).first()
    if existing_id:
        return jsonify({'error': 'Employee ID already exists'}), 400
    
    # Check if current user can be the manager
    manager_id = data.get('manager_id')
    if manager_id:
        if not can_access_employee(manager_id):
            return jsonify({'error': 'You cannot set this manager'}), 403
    
    # Create the employee
    employee = Employee(
        name=data['name'],
        email=data['email'],
        employee_id=data['employee_id'],
        position=data['position'],
        department=data['department'],
        manager_id=data.get('manager_id'),
        is_active=data.get('is_active', True)
    )
    
    # Set a default password (can be changed later)
    employee.set_password('password')
    
    db.session.add(employee)
    db.session.commit()
    
    return jsonify(employee.to_dict()), 201

@employee_bp.route('/api/employees/<int:employee_id>', methods=['PUT', 'PATCH'])
@login_required
def update_employee(employee_id):
    """Update an existing employee."""
    if not can_access_employee(employee_id):
        return jsonify({'error': 'Unauthorized access'}), 403
    
    employee = Employee.query.get_or_404(employee_id)
    data = request.get_json()
    
    # Update fields
    if 'name' in data:
        employee.name = data['name']
    
    if 'email' in data and data['email'] != employee.email:
        # Check if email exists
        existing_email = Employee.query.filter_by(email=data['email']).first()
        if existing_email and existing_email.id != employee_id:
            return jsonify({'error': 'Email already exists'}), 400
        employee.email = data['email']
    
    if 'employee_id' in data and data['employee_id'] != employee.employee_id:
        # Check if employee_id exists
        existing_id = Employee.query.filter_by(employee_id=data['employee_id']).first()
        if existing_id and existing_id.id != employee_id:
            return jsonify({'error': 'Employee ID already exists'}), 400
        employee.employee_id = data['employee_id']
    
    if 'position' in data:
        employee.position = data['position']
    
    if 'department' in data:
        employee.department = data['department']
    
    if 'manager_id' in data and data['manager_id'] != employee.manager_id:
        # Prevent circular reference
        if data['manager_id'] == employee.id:
            return jsonify({'error': 'An employee cannot be their own manager'}), 400
        
        # Check if current user can set this manager
        if data['manager_id'] and not can_access_employee(data['manager_id']):
            return jsonify({'error': 'You cannot set this manager'}), 403
        
        employee.manager_id = data['manager_id']
    
    if 'is_active' in data:
        employee.is_active = data['is_active']
    
    if 'password' in data and data['password']:
        employee.set_password(data['password'])
    
    db.session.commit()
    
    return jsonify(employee.to_dict())

@employee_bp.route('/api/employees/<int:employee_id>', methods=['DELETE'])
@login_required
def delete_employee(employee_id):
    """Delete an employee."""
    if not can_access_employee(employee_id):
        return jsonify({'error': 'Unauthorized access'}), 403
    
    employee = Employee.query.get_or_404(employee_id)
    
    # Check if employee has direct reports
    if Employee.query.filter_by(manager_id=employee.id).count() > 0:
        return jsonify({'error': 'Cannot delete an employee with direct reports'}), 400
    
    db.session.delete(employee)
    db.session.commit()
    
    return jsonify({'success': True})

@employee_bp.route('/api/import-employees', methods=['POST'])
@login_required
def import_employees():
    """Import multiple employees from a file."""
    if request.content_type.startswith('application/json'):
        # Handle JSON import
        data = request.get_json()
        
        if not data or not isinstance(data, list):
            return jsonify({'error': 'Invalid data format'}), 400
        
        created = []
        errors = []
        
        for index, employee_data in enumerate(data):
            try:
                # Basic validation
                required_fields = ['name', 'email', 'employee_id', 'position', 'department']
                for field in required_fields:
                    if field not in employee_data or not employee_data[field]:
                        raise ValueError(f'Missing required field: {field}')
                
                # Email validation
                if not re.match(r"[^@]+@[^@]+\.[^@]+", employee_data['email']):
                    raise ValueError('Invalid email format')
                
                # Check if email exists
                existing_email = Employee.query.filter_by(email=employee_data['email']).first()
                if existing_email:
                    raise ValueError('Email already exists')
                
                # Check if employee_id exists
                existing_id = Employee.query.filter_by(employee_id=employee_data['employee_id']).first()
                if existing_id:
                    raise ValueError('Employee ID already exists')
                
                # Create the employee
                employee = Employee(
                    name=employee_data['name'],
                    email=employee_data['email'],
                    employee_id=employee_data['employee_id'],
                    position=employee_data['position'],
                    department=employee_data['department'],
                    is_active=employee_data.get('is_active', True)
                )
                
                # Set a default password (can be changed later)
                employee.set_password('password')
                
                db.session.add(employee)
                created.append(employee_data)
                
            except ValueError as e:
                errors.append({
                    'index': index,
                    'data': employee_data,
                    'error': str(e)
                })
        
        # Commit if we have any successful imports
        if created:
            db.session.commit()
        
        return jsonify({
            'success': len(created) > 0,
            'created': len(created),
            'errors': errors
        })
    else:
        # Handle file upload (Excel)
        if 'file' not in request.files:
            return jsonify({"error": "No file part"}), 400
            
        file = request.files['file']
        if file.filename == '':
            return jsonify({"error": "No selected file"}), 400
            
        # Check file extension
        if not file.filename.lower().endswith(('.xlsx', '.xls')):
            return jsonify({"error": "Invalid file type. Please upload an Excel file (.xlsx or .xls)"}), 400
            
        # Save file temporarily
        import tempfile
        import os
        from app.utils.excel_import import import_employees_from_excel
        
        temp_dir = tempfile.gettempdir()
        file_path = os.path.join(temp_dir, file.filename)
        file.save(file_path)
        
        # Process Excel file
        try:
            result = import_employees_from_excel(file_path)
            # Clean up temp file
            os.remove(file_path)
            return jsonify(result)
        except Exception as e:
            # Clean up temp file
            os.remove(file_path)
            return jsonify({"success": False, "error": str(e)}), 500