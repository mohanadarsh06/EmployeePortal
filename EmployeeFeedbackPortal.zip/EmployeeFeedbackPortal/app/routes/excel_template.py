"""Routes for generating Excel templates."""
import os
from flask import Blueprint, send_file, current_app
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

excel_template_bp = Blueprint('excel_template', __name__, url_prefix='/api/excel')

@excel_template_bp.route('/employee-template', methods=['GET'])
def employee_import_template():
    """Generate an Excel template for employee import."""
    # Create a workbook and select the active worksheet
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "Employee Template"
    
    # Define headers
    headers = [
        "name", "email", "employee_id", "position", "department", 
        "manager_name", "join_date", "is_active"
    ]
    
    # Add header row with formatting
    header_fill = PatternFill(start_color="1F4E78", end_color="1F4E78", fill_type="solid")
    header_font = Font(color="FFFFFF", bold=True)
    header_alignment = Alignment(horizontal='center', vertical='center')
    
    for col_num, header in enumerate(headers, 1):
        cell = sheet.cell(row=1, column=col_num)
        cell.value = header
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = header_alignment
    
    # Add example data
    example_data = [
        ["John Smith", "john.smith@example.com", "EMP001", "Manager", "Engineering", "", "2023-01-15", "TRUE"],
        ["Jane Doe", "jane.doe@example.com", "EMP002", "Developer", "Engineering", "John Smith", "2023-02-20", "TRUE"],
        ["Bob Johnson", "bob.johnson@example.com", "EMP003", "Designer", "Design", "John Smith", "2023-03-10", "TRUE"]
    ]
    
    data_alignment = Alignment(horizontal='left', vertical='center')
    
    for row_num, row_data in enumerate(example_data, 2):
        for col_num, value in enumerate(row_data, 1):
            cell = sheet.cell(row=row_num, column=col_num)
            cell.value = value
            cell.alignment = data_alignment
    
    # Add a comments row with field descriptions
    comments = [
        "Required: Full name",
        "Required: Email address",
        "Required: Unique ID",
        "Required: Job title",
        "Required: Department/team",
        "Optional: Manager's full name",
        "Optional: YYYY-MM-DD",
        "Optional: TRUE/FALSE"
    ]
    
    comment_font = Font(italic=True, color="808080")
    comment_alignment = Alignment(horizontal='left', vertical='center', wrap_text=True)
    
    for col_num, comment in enumerate(comments, 1):
        cell = sheet.cell(row=5, column=col_num)
        cell.value = comment
        cell.font = comment_font
        cell.alignment = comment_alignment
    
    # Auto-adjust column widths
    for col_num, header in enumerate(headers, 1):
        column_letter = openpyxl.utils.get_column_letter(col_num)
        column_width = max(len(header), 15)  # Set minimum width to 15
        
        # Check example data for wider contents
        for row_num in range(2, 5):
            cell_value = sheet.cell(row=row_num, column=col_num).value
            if cell_value:
                column_width = max(column_width, len(str(cell_value)))
        
        # Add a little extra space and set width
        sheet.column_dimensions[column_letter].width = column_width + 4
    
    # Set row heights
    sheet.row_dimensions[1].height = 24  # Header row
    for i in range(2, 6):
        sheet.row_dimensions[i].height = 18  # Data rows
    
    # Create the temporary file
    template_dir = os.path.join(current_app.root_path, 'static', 'files')
    os.makedirs(template_dir, exist_ok=True)
    file_path = os.path.join(template_dir, 'employee_import_template.xlsx')
    
    # Save the workbook
    workbook.save(file_path)
    
    # Send the file
    return send_file(file_path, 
                    mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                    download_name='employee_import_template.xlsx',
                    as_attachment=True)