from flask import Blueprint, render_template, jsonify
from flask_login import login_required, current_user
from app.models import Employee, Feedback, db
from sqlalchemy import func
from datetime import datetime, timedelta
import calendar

dashboard_bp = Blueprint('dashboard', __name__, url_prefix='/dashboard')

@dashboard_bp.route('/')
@login_required
def index():
    """Render the dashboard page."""
    return render_template('dashboard/index.html')

@dashboard_bp.route('/api/stats')
@login_required
def get_dashboard_stats():
    """Get dashboard statistics."""
    # Get all reportees
    reportees = current_user.get_all_reportees()
    reportee_ids = [r.id for r in reportees]
    reportee_ids.append(current_user.id)  # Include current user
    
    # Total team members (including current user)
    total_team = len(reportee_ids)
    
    # Total feedback count
    total_feedback = Feedback.query.filter(Feedback.employee_id.in_(reportee_ids)).count()
    
    # Average rating
    avg_rating = db.session.query(func.avg(Feedback.rating)).filter(
        Feedback.employee_id.in_(reportee_ids)
    ).scalar() or 0
    avg_rating = round(float(avg_rating), 1)
    
    # Feedback given this month
    now = datetime.now()
    start_of_month = datetime(now.year, now.month, 1).date()
    feedback_this_month = Feedback.query.filter(
        Feedback.employee_id.in_(reportee_ids),
        Feedback.feedback_date >= start_of_month
    ).count()
    
    return jsonify({
        'totalTeam': total_team,
        'totalFeedback': total_feedback,
        'averageRating': avg_rating,
        'feedbackThisMonth': feedback_this_month
    })

@dashboard_bp.route('/api/recent-feedback')
@login_required
def get_recent_feedback():
    """Get recent feedback for the dashboard."""
    # Get all reportees
    reportees = current_user.get_all_reportees()
    reportee_ids = [r.id for r in reportees]
    reportee_ids.append(current_user.id)  # Include current user
    
    # Get recent feedback (last 5)
    recent_feedback = Feedback.query.filter(
        Feedback.employee_id.in_(reportee_ids)
    ).order_by(Feedback.id.desc()).limit(5).all()
    
    result = []
    for feedback in recent_feedback:
        # Get employee info
        employee = Employee.query.get(feedback.employee_id)
        # Get giver info
        giver = Employee.query.get(feedback.giver_id)
        
        feedback_dict = feedback.to_dict()
        feedback_dict['employeeName'] = employee.name if employee else 'Unknown'
        feedback_dict['giverName'] = giver.name if giver else 'Unknown'
        
        employee_initials = ''.join([part[0].upper() for part in employee.name.split()]) if employee else 'UN'
        feedback_dict['employeeInitials'] = employee_initials
        
        result.append(feedback_dict)
    
    return jsonify(result)

@dashboard_bp.route('/api/feedback-by-month')
@login_required
def get_feedback_by_month():
    """Get feedback count by month for the current year."""
    # Get all reportees
    reportees = current_user.get_all_reportees()
    reportee_ids = [r.id for r in reportees]
    reportee_ids.append(current_user.id)  # Include current user
    
    # Get current year
    current_year = datetime.now().year
    
    # Initialize data structure
    months = {i: 0 for i in range(1, 13)}
    
    # Get feedback counts by month
    feedback_by_month = db.session.query(
        func.month(Feedback.feedback_date),
        func.count(Feedback.id)
    ).filter(
        Feedback.employee_id.in_(reportee_ids),
        func.extract('year', Feedback.feedback_date) == current_year
    ).group_by(
        func.month(Feedback.feedback_date)
    ).all()
    
    # Update the counts
    for month, count in feedback_by_month:
        months[month] = count
    
    # Convert to list format for chart
    result = []
    for month_num, count in months.items():
        month_name = calendar.month_name[month_num]
        result.append({
            'month': month_name,
            'count': count
        })
    
    return jsonify(result)

@dashboard_bp.route('/api/rating-distribution')
@login_required
def get_rating_distribution():
    """Get distribution of ratings for the team."""
    # Get all reportees
    reportees = current_user.get_all_reportees()
    reportee_ids = [r.id for r in reportees]
    reportee_ids.append(current_user.id)  # Include current user
    
    # Initialize data structure
    ratings = {i: 0 for i in range(1, 6)}
    
    # Get feedback counts by rating
    rating_distribution = db.session.query(
        Feedback.rating,
        func.count(Feedback.id)
    ).filter(
        Feedback.employee_id.in_(reportee_ids)
    ).group_by(
        Feedback.rating
    ).all()
    
    # Update the counts
    for rating, count in rating_distribution:
        ratings[rating] = count
    
    # Convert to list format for chart
    result = []
    for rating, count in ratings.items():
        result.append({
            'rating': rating,
            'count': count
        })
    
    return jsonify(result)