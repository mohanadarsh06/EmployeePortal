from flask import Blueprint, render_template, redirect, url_for, request, flash, jsonify
from flask_login import login_required, current_user
from app.models import Employee, Feedback, db
from app.routes.employees import can_access_employee
from datetime import datetime
import json

feedback_bp = Blueprint('feedback', __name__, url_prefix='/feedback')

@feedback_bp.route('/')
@login_required
def index():
    """Render the feedback page."""
    return render_template('feedback/index.html')

@feedback_bp.route('/api/feedback')
@login_required
def get_all_feedback():
    """Get all feedback that the current user has access to."""
    # Include feedback for the current user
    employee_ids = [current_user.id]
    
    # Include feedback for reportees
    reportees = current_user.get_all_reportees()
    employee_ids.extend([r.id for r in reportees])
    
    # Get all feedback for these employees
    feedback_list = Feedback.query.filter(Feedback.employee_id.in_(employee_ids)).all()
    
    # Enhance feedback with employee and giver names
    result = []
    for feedback in feedback_list:
        # Get employee info
        employee = Employee.query.get(feedback.employee_id)
        # Get giver info
        giver = Employee.query.get(feedback.giver_id)
        
        feedback_dict = feedback.to_dict()
        feedback_dict['employeeName'] = employee.name if employee else 'Unknown'
        feedback_dict['giverName'] = giver.name if giver else 'Unknown'
        
        employee_initials = ''.join([part[0].upper() for part in employee.name.split()]) if employee else 'UN'
        feedback_dict['employeeInitials'] = employee_initials
        
        result.append(feedback_dict)
    
    return jsonify(result)

@feedback_bp.route('/api/feedback/<int:feedback_id>')
@login_required
def get_feedback(feedback_id):
    """Get a specific feedback."""
    feedback = Feedback.query.get_or_404(feedback_id)
    
    # Check if the user can access this feedback
    if not can_access_employee(feedback.employee_id) and feedback.giver_id != current_user.id:
        return jsonify({'error': 'Unauthorized access'}), 403
    
    # Get employee info
    employee = Employee.query.get(feedback.employee_id)
    # Get giver info
    giver = Employee.query.get(feedback.giver_id)
    
    feedback_dict = feedback.to_dict()
    feedback_dict['employeeName'] = employee.name if employee else 'Unknown'
    feedback_dict['giverName'] = giver.name if giver else 'Unknown'
    
    employee_initials = ''.join([part[0].upper() for part in employee.name.split()]) if employee else 'UN'
    feedback_dict['employeeInitials'] = employee_initials
    
    return jsonify(feedback_dict)

@feedback_bp.route('/api/feedback', methods=['POST'])
@login_required
def create_feedback():
    """Create a new feedback."""
    data = request.get_json()
    
    # Basic validation
    required_fields = ['employee_id', 'rating', 'comment']
    for field in required_fields:
        if field not in data or data[field] is None:
            return jsonify({'error': f'Missing required field: {field}'}), 400
    
    # Rating validation
    if not isinstance(data['rating'], int) or data['rating'] < 1 or data['rating'] > 5:
        return jsonify({'error': 'Rating must be an integer between 1 and 5'}), 400
    
    # Check if the user can give feedback to this employee
    if not can_access_employee(data['employee_id']):
        return jsonify({'error': 'Unauthorized access to this employee'}), 403
    
    # Create the feedback
    feedback = Feedback(
        employee_id=data['employee_id'],
        giver_id=current_user.id,
        rating=data['rating'],
        comment=data['comment'],
        feedback_date=datetime.now().date(),
        areas_for_improvement=data.get('areas_for_improvement'),
        categories=data.get('categories')
    )
    
    db.session.add(feedback)
    db.session.commit()
    
    # Get employee info for response
    employee = Employee.query.get(feedback.employee_id)
    
    feedback_dict = feedback.to_dict()
    feedback_dict['employeeName'] = employee.name if employee else 'Unknown'
    feedback_dict['giverName'] = current_user.name
    
    employee_initials = ''.join([part[0].upper() for part in employee.name.split()]) if employee else 'UN'
    feedback_dict['employeeInitials'] = employee_initials
    
    return jsonify(feedback_dict), 201

@feedback_bp.route('/api/feedback/<int:feedback_id>', methods=['PUT', 'PATCH'])
@login_required
def update_feedback(feedback_id):
    """Update an existing feedback."""
    feedback = Feedback.query.get_or_404(feedback_id)
    
    # Check if the user is the giver of this feedback
    if feedback.giver_id != current_user.id:
        return jsonify({'error': 'You can only update feedback that you have given'}), 403
    
    data = request.get_json()
    
    # Update fields
    if 'rating' in data:
        if not isinstance(data['rating'], int) or data['rating'] < 1 or data['rating'] > 5:
            return jsonify({'error': 'Rating must be an integer between 1 and 5'}), 400
        feedback.rating = data['rating']
    
    if 'comment' in data:
        feedback.comment = data['comment']
    
    if 'areas_for_improvement' in data:
        feedback.areas_for_improvement = data['areas_for_improvement']
    
    if 'categories' in data:
        feedback.categories = data['categories']
    
    db.session.commit()
    
    # Get employee info for response
    employee = Employee.query.get(feedback.employee_id)
    
    feedback_dict = feedback.to_dict()
    feedback_dict['employeeName'] = employee.name if employee else 'Unknown'
    feedback_dict['giverName'] = current_user.name
    
    employee_initials = ''.join([part[0].upper() for part in employee.name.split()]) if employee else 'UN'
    feedback_dict['employeeInitials'] = employee_initials
    
    return jsonify(feedback_dict)

@feedback_bp.route('/api/feedback/<int:feedback_id>', methods=['DELETE'])
@login_required
def delete_feedback(feedback_id):
    """Delete a feedback."""
    feedback = Feedback.query.get_or_404(feedback_id)
    
    # Check if the user is the giver of this feedback
    if feedback.giver_id != current_user.id:
        return jsonify({'error': 'You can only delete feedback that you have given'}), 403
    
    db.session.delete(feedback)
    db.session.commit()
    
    return jsonify({'success': True})

@feedback_bp.route('/api/employees/<int:employee_id>/feedback')
@login_required
def get_employee_feedback(employee_id):
    """Get all feedback for a specific employee."""
    if not can_access_employee(employee_id):
        return jsonify({'error': 'Unauthorized access'}), 403
    
    feedback_list = Feedback.query.filter_by(employee_id=employee_id).all()
    
    # Enhance feedback with employee and giver names
    result = []
    for feedback in feedback_list:
        # Get employee info
        employee = Employee.query.get(feedback.employee_id)
        # Get giver info
        giver = Employee.query.get(feedback.giver_id)
        
        feedback_dict = feedback.to_dict()
        feedback_dict['employeeName'] = employee.name if employee else 'Unknown'
        feedback_dict['giverName'] = giver.name if giver else 'Unknown'
        
        employee_initials = ''.join([part[0].upper() for part in employee.name.split()]) if employee else 'UN'
        feedback_dict['employeeInitials'] = employee_initials
        
        result.append(feedback_dict)
    
    return jsonify(result)

@feedback_bp.route('/api/my-given-feedback')
@login_required
def get_given_feedback():
    """Get all feedback given by the current user."""
    feedback_list = Feedback.query.filter_by(giver_id=current_user.id).all()
    
    # Enhance feedback with employee names
    result = []
    for feedback in feedback_list:
        # Get employee info
        employee = Employee.query.get(feedback.employee_id)
        
        feedback_dict = feedback.to_dict()
        feedback_dict['employeeName'] = employee.name if employee else 'Unknown'
        feedback_dict['giverName'] = current_user.name
        
        employee_initials = ''.join([part[0].upper() for part in employee.name.split()]) if employee else 'UN'
        feedback_dict['employeeInitials'] = employee_initials
        
        result.append(feedback_dict)
    
    return jsonify(result)