from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import json

# Initialize SQLAlchemy
db = SQLAlchemy()

class Employee(db.Model, UserMixin):
    """Employee model that also serves as the user model for authentication."""
    __tablename__ = 'employees'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.Text, nullable=False)
    email = db.Column(db.Text, unique=True, nullable=False)
    # Note: password_hash is not in the database schema, we'll use a default for authentication
    employee_id = db.Column(db.Text, unique=True, nullable=False)
    position = db.Column(db.Text, nullable=False)
    department = db.Column(db.Text, nullable=False)
    manager_id = db.Column(db.Integer, db.ForeignKey('employees.id'), nullable=True)
    join_date = db.Column(db.DateTime, default=datetime.now)
    is_active = db.Column(db.Boolean, default=True)
    
    # Relationship for the manager
    manager = db.relationship('Employee', remote_side=[id], backref=db.backref('direct_reports', lazy='dynamic'))
    
    # Relationships for feedback
    received_feedback = db.relationship('Feedback', foreign_keys='Feedback.employee_id', backref='employee', lazy='dynamic')
    given_feedback = db.relationship('Feedback', foreign_keys='Feedback.giver_id', backref='giver', lazy='dynamic')
    
    # For demo purposes, all passwords are 'password'
    def set_password(self, password):
        """Set the password for the employee (not stored in database)."""
        # In a real app, we would store this in the database
        pass
        
    def check_password(self, password):
        """Check if the provided password matches (simplified for demo)."""
        # For demo purposes, accept any password
        return password == 'password'
    
    def get_all_reportees(self):
        """Get all direct and indirect reportees of an employee."""
        reportees = []
        
        def get_reportees(manager_id):
            direct_reports = Employee.query.filter_by(manager_id=manager_id).all()
            for employee in direct_reports:
                reportees.append(employee)
                get_reportees(employee.id)
                
        get_reportees(self.id)
        return reportees
    
    def get_management_chain(self):
        """Get the management chain of an employee up to the top."""
        chain = []
        current = self
        
        while current.manager_id:
            manager = Employee.query.get(current.manager_id)
            if manager:
                chain.append(manager)
                current = manager
            else:
                break
                
        return chain
    
    def to_dict(self):
        """Convert employee to dictionary for JSON serialization."""
        return {
            'id': self.id,
            'name': self.name,
            'email': self.email,
            'employee_id': self.employee_id,
            'position': self.position,
            'department': self.department,
            'manager_id': self.manager_id,
            'join_date': self.join_date.isoformat() if self.join_date else None,
            'is_active': self.is_active
        }
    
    def __repr__(self):
        return f'<Employee {self.name} ({self.employee_id})>'

class Feedback(db.Model):
    """Feedback model for storing feedback records."""
    __tablename__ = 'feedbacks'
    
    id = db.Column(db.Integer, primary_key=True)
    employee_id = db.Column(db.Integer, db.ForeignKey('employees.id'), nullable=False)
    giver_id = db.Column(db.Integer, db.ForeignKey('employees.id'), nullable=False)
    rating = db.Column(db.Integer, nullable=False)
    comment = db.Column(db.Text, nullable=False)
    feedback_date = db.Column(db.DateTime, default=datetime.now)
    areas_for_improvement = db.Column(db.Text, nullable=True)
    categories = db.Column(db.Text, nullable=True)
    
    def to_dict(self):
        """Convert feedback to dictionary for JSON serialization."""
        return {
            'id': self.id,
            'employee_id': self.employee_id,
            'giver_id': self.giver_id,
            'rating': self.rating,
            'comment': self.comment,
            'feedback_date': self.feedback_date.isoformat() if self.feedback_date else None,
            'areas_for_improvement': self.areas_for_improvement,
            'categories': self.categories
        }
    
    def __repr__(self):
        return f'<Feedback for Employee #{self.employee_id} by #{self.giver_id}>'