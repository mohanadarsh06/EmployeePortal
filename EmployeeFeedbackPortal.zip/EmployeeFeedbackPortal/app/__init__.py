from flask import Flask
from flask_login import LoginManager
from .config import Config
from .models import db, Employee
from .utils.template_filters import register_filters

# Create and configure login manager
login_manager = LoginManager()
login_manager.login_view = 'auth.login'
login_manager.login_message_category = 'info'

@login_manager.user_loader
def load_user(user_id):
    """Load user by ID for Flask-Login."""
    return Employee.query.get(int(user_id))

def create_app(config_class=Config):
    """Create and configure the Flask application."""
    app = Flask(__name__)
    app.config.from_object(config_class)
    
    # Initialize extensions
    db.init_app(app)
    login_manager.init_app(app)
    
    # Register template filters
    register_filters(app)
    
    # Import and register blueprints
    from .routes.auth import auth_bp
    from .routes.employees import employee_bp
    from .routes.feedback import feedback_bp
    from .routes.dashboard import dashboard_bp
    from .routes.excel_template import excel_template_bp
    
    app.register_blueprint(auth_bp)
    app.register_blueprint(employee_bp)
    app.register_blueprint(feedback_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(excel_template_bp)
    
    # Create database tables if they don't exist
    with app.app_context():
        db.create_all()
    
    @app.route('/health')
    def health_check():
        """Health check endpoint for monitoring."""
        return {'status': 'healthy'}, 200
    
    return app